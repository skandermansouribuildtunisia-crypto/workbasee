import { useEffect, useState } from 'react';
import { Link, useNavigate, useParams } from 'react-router-dom';
import { ArrowLeft, CalendarDays, Pencil, Plus, Trash2, Users } from 'lucide-react';
import { base44 } from '@/api/base44Client';
import PageHeader from '@/components/common/PageHeader';
import StatTile from '@/components/common/StatTile';
import ProjectDialog from '@/components/projects/ProjectDialog';
import MilestoneList from '@/components/projects/MilestoneList';
import TaskDialog from '@/components/tasks/TaskDialog';
import TaskRow from '@/components/tasks/TaskRow';
import { useCollection } from '@/hooks/useCollection';
import { useWorkspace } from '@/lib/workspace';
import { projectFinance } from '@/lib/derive';
import { longDate, money, shortDate } from '@/lib/format';

export default function ProjectDetail() {
  const { id } = useParams();
  const navigate = useNavigate();
  const { currency } = useWorkspace();
  const [project, setProject] = useState(null);
  const [editOpen, setEditOpen] = useState(false);
  const [taskOpen, setTaskOpen] = useState(false);
  const [editingTask, setEditingTask] = useState(null);

  const tasks = useCollection('Task', { project_id: id }, { sort: 'due_date' });
  const expenses = useCollection('Expense', { project_id: id }, { sort: '-date' });
  const invoices = useCollection('Invoice', { project_id: id }, { sort: '-issue_date' });
  const clients = useCollection('Client', {}, { sort: 'name' });

  const load = async () => {
    const data = await base44.entities.Project.get(id).catch(() => null);
    setProject(data);
  };

  useEffect(() => {
    load();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [id]);

  if (!project) return <div className="h-64 animate-pulse rounded-2xl border border-border bg-card/60" />;

  const f = projectFinance(project, expenses.items, invoices.items, tasks.items);

  const toggleTask = async (task) => {
    await base44.entities.Task.update(task.id, { status: task.status === 'done' ? 'todo' : 'done' });
    tasks.reload();
  };

  const deleteTask = async (task) => {
    await base44.entities.Task.delete(task.id);
    tasks.reload();
  };

  const saveMilestones = async (milestones) => {
    setProject({ ...project, milestones });
    await base44.entities.Project.update(project.id, { milestones });
  };

  const remove = async () => {
    await base44.entities.Project.delete(id);
    navigate('/projects');
  };

  return (
    <div>
      <Link to="/projects" className="mb-6 inline-flex items-center gap-1.5 text-[12.5px] text-muted-foreground hover:text-foreground">
        <ArrowLeft className="h-3.5 w-3.5" /> All projects
      </Link>

      <PageHeader
        eyebrow={`${project.status.replace('_', ' ')} project`}
        title={project.name}
        description={project.client_name ? `For ${project.client_name}` : 'Internal project'}
        actions={
          <>
            <button className="btn-ghost" onClick={() => setEditOpen(true)}>
              <Pencil className="h-4 w-4" /> Edit
            </button>
            <button className="btn-ink" onClick={remove}>
              <Trash2 className="h-4 w-4" /> Delete
            </button>
          </>
        }
      />

      <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 xl:grid-cols-4">
        <StatTile label="Budget" value={money(project.budget, currency, true)} hint="Contracted" />
        <StatTile
          label="Spent"
          value={money(f.spent, currency, true)}
          hint={`${f.burn}% of budget`}
          tone={f.burn > 100 ? 'negative' : 'default'}
        />
        <StatTile label="Invoiced" value={money(f.invoiced, currency, true)} hint={`${money(f.paid, currency, true)} paid`} />
        <StatTile
          label="Profit"
          value={money(f.profit, currency, true)}
          hint="Cash received − costs"
          tone={f.profit < 0 ? 'negative' : 'default'}
        />
      </div>

      <div className="mt-6 grid grid-cols-1 gap-6 xl:grid-cols-3">
        <div className="xl:col-span-2 space-y-6">
          <div className="surface p-5 sm:p-6">
            <div className="mb-4 flex items-center justify-between">
              <h2 className="text-[17px] tracking-[-0.01em]">Tasks</h2>
              <button
                className="btn-ghost px-3 py-1.5 text-[12px]"
                onClick={() => {
                  setEditingTask(null);
                  setTaskOpen(true);
                }}
              >
                <Plus className="h-3.5 w-3.5" /> Add task
              </button>
            </div>
            <div className="divide-y divide-border">
              {tasks.items.map((t) => (
                <TaskRow
                  key={t.id}
                  task={t}
                  onToggle={() => toggleTask(t)}
                  onEdit={() => {
                    setEditingTask(t);
                    setTaskOpen(true);
                  }}
                  onDelete={() => deleteTask(t)}
                />
              ))}
              {tasks.items.length === 0 && (
                <p className="py-6 text-center text-[12.5px] text-muted-foreground">No tasks yet for this project.</p>
              )}
            </div>
          </div>

          <div className="surface p-5 sm:p-6">
            <div className="mb-4 flex items-center justify-between">
              <h2 className="text-[17px] tracking-[-0.01em]">Milestones</h2>
              <span className="text-[11.5px] text-muted-foreground">
                {(project.milestones || []).filter((m) => m.done).length}/{project.milestones?.length || 0} reached
              </span>
            </div>
            <MilestoneList milestones={project.milestones || []} onChange={saveMilestones} />
          </div>

          <div className="surface p-5 sm:p-6">
            <h2 className="mb-4 text-[17px] tracking-[-0.01em]">Project costs</h2>
            <div className="divide-y divide-border">
              {expenses.items.map((e) => (
                <div key={e.id} className="flex items-center justify-between py-2.5">
                  <div>
                    <p className="text-[13px]">{e.description}</p>
                    <p className="text-[11px] capitalize text-muted-foreground">
                      {e.category} · {shortDate(e.date)}
                    </p>
                  </div>
                  <span className="num text-[14px]">{money(e.amount, currency)}</span>
                </div>
              ))}
              {expenses.items.length === 0 && (
                <p className="py-4 text-[12.5px] text-muted-foreground">No costs logged against this project.</p>
              )}
            </div>
          </div>
        </div>

        <div className="space-y-6">
          <div className="surface p-5">
            <h2 className="mb-4 text-[17px] tracking-[-0.01em]">Brief</h2>
            <p className="text-[12.5px] leading-relaxed text-muted-foreground">
              {project.description || 'No description yet.'}
            </p>
            {project.objective && (
              <div className="mt-4 rounded-xl bg-accent/20 p-3">
                <p className="text-[10px] uppercase tracking-[0.12em] text-foreground/60">Objective</p>
                <p className="mt-1 text-[12.5px] leading-relaxed">{project.objective}</p>
              </div>
            )}
            <div className="mt-4 space-y-2 border-t border-border pt-4 text-[12.5px]">
              <p className="flex items-center gap-2 text-muted-foreground">
                <CalendarDays className="h-3.5 w-3.5" /> {longDate(project.start_date)} → {longDate(project.due_date)}
              </p>
              <p className="flex items-start gap-2 text-muted-foreground">
                <Users className="mt-0.5 h-3.5 w-3.5" />
                <span>{(project.team || []).join(', ') || 'No team assigned'}</span>
              </p>
            </div>
          </div>

          <div className="surface p-5">
            <h2 className="mb-4 text-[17px] tracking-[-0.01em]">Invoices</h2>
            <div className="divide-y divide-border">
              {invoices.items.map((inv) => (
                <Link key={inv.id} to={`/invoices/${inv.id}`} className="row-hover flex items-center justify-between rounded-lg px-2 py-2.5">
                  <div>
                    <p className="text-[12.5px] font-medium">{inv.number}</p>
                    <p className="text-[11px] capitalize text-muted-foreground">{inv.status}</p>
                  </div>
                  <span className="num text-[14px]">{money(inv.total, currency)}</span>
                </Link>
              ))}
              {invoices.items.length === 0 && (
                <p className="py-3 text-[12.5px] text-muted-foreground">Nothing invoiced yet.</p>
              )}
            </div>
          </div>
        </div>
      </div>

      <ProjectDialog
        open={editOpen}
        project={project}
        clients={clients.items}
        onClose={() => setEditOpen(false)}
        onSaved={load}
      />
      <TaskDialog
        open={taskOpen}
        task={editingTask}
        project={project}
        onClose={() => setTaskOpen(false)}
        onSaved={tasks.reload}
      />
    </div>
  );
}
