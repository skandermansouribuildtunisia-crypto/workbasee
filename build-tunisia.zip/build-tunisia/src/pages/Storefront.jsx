import { useEffect, useMemo, useState } from 'react';
import { Link } from 'react-router-dom';
import { Loader2, Search, ShoppingBag } from 'lucide-react';
import { base44 } from '@/api/base44Client';
import { useCart } from '@/lib/cart';
import StoreHero from '@/components/store/StoreHero';
import ProductTile from '@/components/store/ProductTile';
import CartDrawer from '@/components/store/CartDrawer';

export default function Storefront() {
  const [data, setData] = useState(null);
  const [error, setError] = useState('');
  const [category, setCategory] = useState('all');
  const [query, setQuery] = useState('');
  const [cartOpen, setCartOpen] = useState(false);
  const cart = useCart();
  const canceled = new URLSearchParams(window.location.search).get('canceled') === '1';

  useEffect(() => {
    base44.functions
      .invoke('storefront', {})
      .then((res) => setData(res.data))
      .catch((err) => setError(err?.response?.data?.error || 'The shop could not be loaded.'));
  }, []);

  const products = data?.products || [];
  const currency = data?.store?.currency || 'USD';
  const storeName = data?.store?.name || 'Our store';

  const categories = useMemo(
    () => ['all', ...Array.from(new Set(products.map((p) => p.category)))],
    [products],
  );

  const visible = products.filter((product) => {
    if (category !== 'all' && product.category !== category) return false;
    const q = query.trim().toLowerCase();
    if (q && !`${product.name} ${product.description}`.toLowerCase().includes(q)) return false;
    return true;
  });

  return (
    <div className="min-h-screen bg-background">
      <header className="sticky top-0 z-40 border-b border-border bg-background/85 backdrop-blur">
        <div className="mx-auto flex max-w-6xl items-center justify-between px-5 py-3.5">
          <div className="flex items-center gap-2">
            <span className="h-2.5 w-2.5 rounded-full bg-accent" />
            <span className="text-[12.5px] font-semibold uppercase tracking-[0.2em]">{storeName}</span>
          </div>
          <div className="flex items-center gap-3">
            <Link to="/login" className="hidden text-[12px] text-muted-foreground hover:underline sm:block">
              Owner login
            </Link>
            <button
              onClick={() => setCartOpen(true)}
              className="relative inline-flex items-center gap-2 rounded-full bg-primary px-4 py-2 text-[12.5px] font-medium text-primary-foreground transition hover:opacity-90 active:scale-[0.98]"
            >
              <ShoppingBag className="h-4 w-4" />
              Bag
              <span className="rounded-full bg-accent px-1.5 py-0.5 text-[10.5px] font-semibold text-accent-foreground">
                {cart.count}
              </span>
            </button>
          </div>
        </div>
      </header>

      <main className="mx-auto max-w-6xl px-5 py-8">
        <StoreHero store={data?.store} />

        {canceled && (
          <p className="mt-5 rounded-xl bg-secondary px-4 py-3 text-[12.5px] text-muted-foreground">
            Checkout was cancelled — your bag is still saved.
          </p>
        )}

        <div className="mb-5 mt-9 flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
          <div className="flex flex-wrap gap-1.5">
            {categories.map((value) => (
              <button
                key={value}
                onClick={() => setCategory(value)}
                className={`rounded-full px-3.5 py-1.5 text-[11.5px] capitalize transition ${
                  category === value
                    ? 'bg-primary text-primary-foreground'
                    : 'border border-border bg-card text-muted-foreground hover:text-foreground'
                }`}
              >
                {value === 'all' ? 'Everything' : value}
              </button>
            ))}
          </div>
          <div className="relative">
            <Search className="pointer-events-none absolute left-3 top-1/2 h-3.5 w-3.5 -translate-y-1/2 text-muted-foreground" />
            <input
              value={query}
              onChange={(e) => setQuery(e.target.value)}
              placeholder="Search products…"
              className="field w-full py-2 pl-8 sm:w-64"
            />
          </div>
        </div>

        {error && <p className="rounded-xl bg-destructive/10 p-4 text-[12.5px] text-destructive">{error}</p>}

        {!data && !error && (
          <div className="flex items-center gap-2 py-16 text-[13px] text-muted-foreground">
            <Loader2 className="h-4 w-4 animate-spin" /> Opening the shop…
          </div>
        )}

        {data && products.length === 0 && (
          <div className="rounded-2xl border border-dashed border-border bg-card/50 px-6 py-16 text-center">
            <p className="text-[15px] font-medium">The shop is not open yet</p>
            <p className="mx-auto mt-1 max-w-sm text-[12.5px] leading-relaxed text-muted-foreground">
              No products are published. In Inventory, open a product and turn on “Show in online store”
              to put it on sale here.
            </p>
          </div>
        )}

        {visible.length > 0 && (
          <div className="grid gap-5 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4">
            {visible.map((product, i) => (
              <ProductTile
                key={product.id}
                product={product}
                currency={currency}
                index={i}
                onAdd={(item) => cart.add(item)}
              />
            ))}
          </div>
        )}

        {data && products.length > 0 && visible.length === 0 && (
          <p className="py-16 text-center text-[12.5px] text-muted-foreground">
            Nothing matches that search.
          </p>
        )}

        <p className="mt-14 text-center text-[11px] text-muted-foreground">Powered by workbase</p>
      </main>

      <CartDrawer open={cartOpen} onClose={() => setCartOpen(false)} cart={cart} currency={currency} />
    </div>
  );
}
