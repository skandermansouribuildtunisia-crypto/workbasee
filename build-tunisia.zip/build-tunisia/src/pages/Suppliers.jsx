import { useMemo, useState } from 'react';
import { Pencil, Plus, Search, Trash2, Truck } from 'lucide-react';
import PageHeader from '@/components/common/PageHeader';
import EmptyState from '@/components/common/EmptyState';
import SupplierDialog from '@/components/suppliers/SupplierDialog';
import { useCollection } from '@/hooks/useCollection';
import { base44 } from '@/api/base44Client';

const CATEGORY_LABEL = {
  materials: 'Materials',
  products: 'Products',
  logistics: 'Logistics',
  software: 'Software',
  services: 'Services',
  other: 'Other',
};

export default function Suppliers() {
  const suppliers = useCollection('Supplier', {}, { sort: 'name' });
  const products = useCollection('Product', {}, { sort: 'name' });
  const [search, setSearch] = useState('');
  const [dialog, setDialog] = useState({ open: false, supplier: null });

  const counts = useMemo(() => {
    const map = {};
    products.items.forEach((p) => {
      if (p.supplier_id) map[p.supplier_id] = (map[p.supplier_id] || 0) + 1;
    });
    return map;
  }, [products.items]);

  const filtered = useMemo(() => {
    const q = search.trim().toLowerCase();
    if (!q) return suppliers.items;
    return suppliers.items.filter((s) =>
      `${s.name} ${s.contact_name || ''} ${s.email || ''} ${s.country || ''}`.toLowerCase().includes(q)
    );
  }, [suppliers.items, search]);

  const remove = async (supplier) => {
    const linked = counts[supplier.id] || 0;
    const warning = linked
      ? `Delete “${supplier.name}”? ${linked} product(s) will be left without a supplier.`
      : `Delete “${supplier.name}”?`;
    if (!window.confirm(warning)) return;
    await base44.entities.Supplier.delete(supplier.id);
    suppliers.reload();
  };

  return (
    <div>
      <PageHeader
        eyebrow="Operations"
        title="Suppliers"
        description={`${suppliers.items.length} suppliers · ${suppliers.items.filter((s) => s.active !== false).length} active`}
        actions={
          <button className="btn-ink" onClick={() => setDialog({ open: true, supplier: null })}>
            <Plus className="h-4 w-4" /> New supplier
          </button>
        }
      />

      {suppliers.items.length > 0 && (
        <div className="mb-4 flex items-center justify-between gap-3">
          <div className="relative w-full sm:w-72">
            <Search className="pointer-events-none absolute left-3 top-1/2 h-3.5 w-3.5 -translate-y-1/2 text-muted-foreground" />
            <input
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              placeholder="Search suppliers…"
              className="field w-full pl-8"
            />
          </div>
        </div>
      )}

      {suppliers.loading ? (
        <div className="h-64 animate-pulse rounded-2xl border border-border bg-card/60" />
      ) : suppliers.items.length === 0 ? (
        <EmptyState
          icon={Truck}
          title="No suppliers yet"
          description="Keep the companies you buy from in one place, then link products to them so reordering is never a hunt."
          action={
            <button className="btn-ink" onClick={() => setDialog({ open: true, supplier: null })}>
              <Plus className="h-4 w-4" /> New supplier
            </button>
          }
        />
      ) : (
        <div className="surface overflow-hidden">
          <div className="hidden grid-cols-[1.6fr_1fr_1.2fr_0.8fr_0.7fr_auto] gap-3 border-b border-border px-4 py-2.5 text-[10.5px] uppercase tracking-[0.12em] text-muted-foreground lg:grid">
            <span>Supplier</span>
            <span>Category</span>
            <span>Contact</span>
            <span>Terms</span>
            <span>Products</span>
            <span className="text-right">Actions</span>
          </div>
          <div className="divide-y divide-border">
            {filtered.map((s) => (
              <div
                key={s.id}
                className="grid grid-cols-2 items-center gap-3 px-4 py-3 transition-colors hover:bg-secondary/40 lg:grid-cols-[1.6fr_1fr_1.2fr_0.8fr_0.7fr_auto]"
              >
                <div className="col-span-2 min-w-0 lg:col-span-1">
                  <p className="truncate text-[13.5px] font-medium">
                    {s.name}
                    {s.active === false && (
                      <span className="ml-2 rounded-full bg-secondary px-2 py-0.5 text-[10px] text-muted-foreground">
                        Inactive
                      </span>
                    )}
                  </p>
                  <p className="truncate text-[11px] text-muted-foreground">
                    {s.contact_name || 'No contact person'}
                    {s.city || s.country ? ` · ${[s.city, s.country].filter(Boolean).join(', ')}` : ''}
                  </p>
                </div>
                <p className="text-[12px] text-muted-foreground">{CATEGORY_LABEL[s.category] || 'Products'}</p>
                <div className="min-w-0 text-[11.5px] text-muted-foreground">
                  <p className="truncate">{s.email || '—'}</p>
                  <p className="truncate">{s.phone || ''}</p>
                </div>
                <p className="text-[12px] text-muted-foreground">{s.payment_terms || '—'}</p>
                <p className="num text-[12.5px]">{counts[s.id] || 0}</p>
                <div className="col-span-2 flex items-center justify-end gap-1 lg:col-span-1">
                  <button
                    onClick={() => setDialog({ open: true, supplier: s })}
                    className="rounded-full border border-border p-1.5 text-muted-foreground transition hover:bg-card hover:text-foreground"
                    title="Edit supplier"
                  >
                    <Pencil className="h-3.5 w-3.5" />
                  </button>
                  <button
                    onClick={() => remove(s)}
                    className="rounded-full border border-border p-1.5 text-muted-foreground transition hover:border-destructive/40 hover:text-destructive"
                    title="Delete supplier"
                  >
                    <Trash2 className="h-3.5 w-3.5" />
                  </button>
                </div>
              </div>
            ))}
            {filtered.length === 0 && (
              <p className="px-4 py-10 text-center text-[12.5px] text-muted-foreground">No suppliers match that search.</p>
            )}
          </div>
        </div>
      )}

      <SupplierDialog
        open={dialog.open}
        supplier={dialog.supplier}
        onClose={() => setDialog({ open: false, supplier: null })}
        onSaved={suppliers.reload}
      />
    </div>
  );
}
