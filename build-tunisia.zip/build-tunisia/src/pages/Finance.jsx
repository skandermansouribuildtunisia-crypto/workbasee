import { useMemo, useState } from 'react';
import { Plus, Trash2, Wallet } from 'lucide-react';
import PageHeader from '@/components/common/PageHeader';
import StatTile from '@/components/common/StatTile';
import EmptyState from '@/components/common/EmptyState';
import ExpenseDialog from '@/components/expenses/ExpenseDialog';
import { useCollection } from '@/hooks/useCollection';
import { useWorkspace } from '@/lib/workspace';
import { expenseByCategory } from '@/lib/derive';
import { base44 } from '@/api/base44Client';
import { money, monthKey, shortDate } from '@/lib/format';

const categories = ['all', 'materials', 'labor', 'software', 'marketing', 'travel', 'rent', 'other'];

export default function Finance() {
  const { currency } = useWorkspace();
  const expenses = useCollection('Expense', {}, { sort: '-date' });
  const projects = useCollection('Project', {}, { sort: 'name' });
  const [dialog, setDialog] = useState({ open: false, expense: null });
  const [filter, setFilter] = useState('all');

  const now = new Date();
  const thisMonthKey = `${now.getFullYear()}-${String(now.getMonth() + 1).padStart(2, '0')}`;

  const stats = useMemo(() => {
    const month = expenses.items
      .filter((e) => e.date && monthKey(e.date) === thisMonthKey)
      .reduce((s, e) => s + (Number(e.amount) || 0), 0);
    const recurring = expenses.items
      .filter((e) => e.recurring)
      .reduce((s, e) => s + (Number(e.amount) || 0), 0);
    const all = expenses.items.reduce((s, e) => s + (Number(e.amount) || 0), 0);
    const byCategory = expenseByCategory(expenses.items);
    return { month, recurring, all, byCategory };
  }, [expenses.items, thisMonthKey]);

  const filtered = filter === 'all' ? expenses.items : expenses.items.filter((e) => e.category === filter);

  const remove = async (expense) => {
    await base44.entities.Expense.delete(expense.id);
    expenses.reload();
  };

  return (
    <div>
      <PageHeader
        eyebrow="Finance"
        title="Expenses"
        description="Every cost in one ledger, attributed to the project that caused it."
        actions={
          <button className="btn-ink" onClick={() => setDialog({ open: true, expense: null })}>
            <Plus className="h-4 w-4" /> Log expense
          </button>
        }
      />

      <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 xl:grid-cols-4">
        <StatTile label="This month" value={money(stats.month, currency)} hint={now.toLocaleDateString('en-US', { month: 'long' })} />
        <StatTile label="Recurring" value={money(stats.recurring, currency)} hint="Monthly commitments" />
        <StatTile label="Total logged" value={money(stats.all, currency, true)} hint={`${expenses.items.length} records`} />
        <StatTile
          label="Biggest category"
          value={stats.byCategory[0] ? stats.byCategory[0].name : '—'}
          hint={stats.byCategory[0] ? money(stats.byCategory[0].value, currency, true) : 'No data'}
        />
      </div>

      <div className="mt-6 grid grid-cols-1 gap-6 xl:grid-cols-3">
        <div className="surface p-5 sm:p-6 xl:col-span-1">
          <h2 className="mb-4 text-[17px] tracking-[-0.01em]">By category</h2>
          <div className="space-y-3">
            {stats.byCategory.map((c) => {
              const share = stats.all ? Math.round((c.value / stats.all) * 100) : 0;
              return (
                <div key={c.name}>
                  <div className="mb-1 flex items-center justify-between text-[12px]">
                    <span className="capitalize">{c.name}</span>
                    <span className="text-muted-foreground">
                      {money(c.value, currency, true)} · {share}%
                    </span>
                  </div>
                  <div className="h-1.5 w-full overflow-hidden rounded-full bg-secondary">
                    <div className="h-full rounded-full bg-primary" style={{ width: `${share}%` }} />
                  </div>
                </div>
              );
            })}
            {stats.byCategory.length === 0 && (
              <p className="py-4 text-[12.5px] text-muted-foreground">No expenses logged yet.</p>
            )}
          </div>
        </div>

        <div className="surface overflow-hidden xl:col-span-2">
          <div className="flex flex-wrap items-center justify-between gap-2 px-5 py-4">
            <h2 className="text-[17px] tracking-[-0.01em]">Ledger</h2>
            <select className="field w-auto py-1.5 text-[12px]" value={filter} onChange={(e) => setFilter(e.target.value)}>
              {categories.map((c) => (
                <option key={c} value={c}>
                  {c === 'all' ? 'All categories' : c[0].toUpperCase() + c.slice(1)}
                </option>
              ))}
            </select>
          </div>

          {expenses.loading ? (
            <div className="h-40 animate-pulse bg-secondary/30" />
          ) : filtered.length === 0 ? (
            <div className="px-5 pb-5">
              <EmptyState
                icon={Wallet}
                title="No expenses in this view"
                description="Log a cost and it will appear in cash flow, project profit and reports."
                action={
                  <button className="btn-ink" onClick={() => setDialog({ open: true, expense: null })}>
                    <Plus className="h-4 w-4" /> Log expense
                  </button>
                }
              />
            </div>
          ) : (
            <div className="overflow-x-auto">
              <table className="w-full min-w-[520px] text-left">
                <thead>
                  <tr className="border-y border-border bg-secondary/40">
                    {['Expense', 'Project', 'Date', 'Category', 'Amount', ''].map((h, i) => (
                      <th
                        key={h + i}
                        className={`px-5 py-2.5 text-[10.5px] font-medium uppercase tracking-[0.12em] text-muted-foreground ${
                          h === 'Amount' ? 'text-right' : ''
                        }`}
                      >
                        {h}
                      </th>
                    ))}
                  </tr>
                </thead>
                <tbody className="divide-y divide-border">
                  {filtered.map((e) => (
                    <tr key={e.id} className="row-hover group">
                      <td className="px-5 py-3">
                        <button
                          className="text-left text-[13px] font-medium hover:underline"
                          onClick={() => setDialog({ open: true, expense: e })}
                        >
                          {e.description}
                        </button>
                        {e.vendor && <p className="text-[11px] text-muted-foreground">{e.vendor}</p>}
                      </td>
                      <td className="px-5 py-3 text-[12px] text-muted-foreground">{e.project_name || 'Overhead'}</td>
                      <td className="px-5 py-3 text-[12px] text-muted-foreground">{shortDate(e.date)}</td>
                      <td className="px-5 py-3">
                        <span className="rounded-full bg-secondary px-2 py-1 text-[10.5px] capitalize text-muted-foreground">
                          {e.category}
                        </span>
                      </td>
                      <td className="num px-5 py-3 text-right text-[14px]">{money(e.amount, currency)}</td>
                      <td className="px-3 py-3">
                        <button
                          onClick={() => remove(e)}
                          className="rounded-full p-1.5 text-muted-foreground opacity-0 transition hover:text-destructive group-hover:opacity-100"
                          aria-label="Delete expense"
                        >
                          <Trash2 className="h-3.5 w-3.5" />
                        </button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </div>
      </div>

      <ExpenseDialog
        open={dialog.open}
        expense={dialog.expense}
        projects={projects.items}
        onClose={() => setDialog({ open: false, expense: null })}
        onSaved={expenses.reload}
      />
    </div>
  );
}
