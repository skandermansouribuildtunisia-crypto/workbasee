import { useEffect, useState } from 'react';
import { Link, useNavigate, useParams } from 'react-router-dom';
import { ArrowLeft, CheckCircle2, Copy, Download, Link2, Pencil, Send, Trash2 } from 'lucide-react';
import { base44 } from '@/api/base44Client';
import InvoiceDialog from '@/components/invoices/InvoiceDialog';
import { useCollection } from '@/hooks/useCollection';
import { useWorkspace } from '@/lib/workspace';
import { downloadInvoicePdf } from '@/lib/invoicePdf';
import { longDate, money } from '@/lib/format';

const statusStyle = {
  paid: 'bg-accent/30 text-foreground',
  sent: 'bg-chart-4/15 text-chart-4',
  overdue: 'bg-destructive/10 text-destructive',
  draft: 'bg-secondary text-muted-foreground',
};

export default function InvoiceDetail() {
  const { id } = useParams();
  const navigate = useNavigate();
  const { currency, company } = useWorkspace();
  const [invoice, setInvoice] = useState(null);
  const [editOpen, setEditOpen] = useState(false);
  const [payLink, setPayLink] = useState('');
  const [linkBusy, setLinkBusy] = useState(false);
  const clients = useCollection('Client', {}, { sort: 'name' });
  const projects = useCollection('Project', {}, { sort: 'name' });

  const load = async () => {
    const data = await base44.entities.Invoice.get(id).catch(() => null);
    setInvoice(data);
  };

  useEffect(() => {
    load();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [id]);

  if (!invoice) return <div className="h-64 animate-pulse rounded-2xl border border-border bg-card/60" />;

  const subtotal = (invoice.items || []).reduce((s, it) => s + (Number(it.qty) || 0) * (Number(it.rate) || 0), 0);
  const tax = subtotal * ((Number(invoice.tax_rate) || 0) / 100);
  const total = Math.round(subtotal + tax);

  const setStatus = async (status) => {
    await base44.entities.Invoice.update(id, { status });
    load();
  };

  const createPayLink = async () => {
    setLinkBusy(true);
    try {
      const res = await base44.functions.invoke('invoicePayLink', { invoice_id: id });
      const url = `${window.location.origin}${res.data.path}`;
      setPayLink(url);
      await navigator.clipboard.writeText(url).catch(() => {});
    } finally {
      setLinkBusy(false);
    }
  };

  const recordPayment = async () => {
    const now = new Date().toISOString();
    await base44.entities.Invoice.update(id, { status: 'paid', paid_at: now, amount_paid: total });
    await base44.entities.Payment.create({
      invoice_id: id,
      invoice_number: invoice.number,
      client_name: invoice.client_name || '',
      amount: total,
      currency,
      method: 'other',
      provider: 'manual',
      status: 'paid',
      paid_at: now,
    });
    load();
  };

  const remove = async () => {
    await base44.entities.Invoice.delete(id);
    navigate('/invoices');
  };

  return (
    <div>
      <Link
        to="/invoices"
        className="mb-6 inline-flex items-center gap-1.5 text-[12.5px] text-muted-foreground hover:text-foreground"
      >
        <ArrowLeft className="h-3.5 w-3.5" /> All invoices
      </Link>

      <div className="mb-6 flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
        <div className="flex items-center gap-3">
          <h1 className="num text-[34px] leading-none">{invoice.number}</h1>
          <span
            className={`rounded-full px-2.5 py-1 text-[10.5px] font-medium capitalize ${
              statusStyle[invoice.status] || statusStyle.draft
            }`}
          >
            {invoice.status}
          </span>
        </div>
        <div className="flex flex-wrap gap-2">
          <button
            className="btn-ghost"
            onClick={() => downloadInvoicePdf(invoice, { company, currency })}
          >
            <Download className="h-4 w-4" /> PDF
          </button>
          {invoice.status === 'draft' && (
            <button className="btn-ghost" onClick={() => setStatus('sent')}>
              <Send className="h-4 w-4" /> Mark sent
            </button>
          )}
          <button className="btn-lime" onClick={createPayLink} disabled={linkBusy}>
            <Link2 className="h-4 w-4" /> {linkBusy ? 'Creating…' : 'Payment link'}
          </button>
          {invoice.status !== 'paid' && (
            <button className="btn-ghost" onClick={recordPayment}>
              <CheckCircle2 className="h-4 w-4" /> Record payment
            </button>
          )}
          <button className="btn-ghost px-3" onClick={() => setEditOpen(true)} aria-label="Edit invoice">
            <Pencil className="h-4 w-4" />
          </button>
          <button className="btn-ghost px-3" onClick={remove} aria-label="Delete invoice">
            <Trash2 className="h-4 w-4" />
          </button>
        </div>
      </div>

      {payLink && (
        <div className="mb-6 flex flex-wrap items-center gap-2 rounded-2xl border border-border bg-secondary/50 px-4 py-3">
          <Link2 className="h-4 w-4 text-muted-foreground" />
          <input readOnly value={payLink} className="min-w-0 flex-1 bg-transparent text-[12.5px] outline-none" />
          <button
            className="btn-ghost px-3 py-1.5 text-[12px]"
            onClick={() => navigator.clipboard.writeText(payLink).catch(() => {})}
          >
            <Copy className="h-3.5 w-3.5" /> Copy
          </button>
          <a className="btn-ghost px-3 py-1.5 text-[12px]" href={payLink} target="_blank" rel="noreferrer">
            Open
          </a>
        </div>
      )}

      <div className="surface mx-auto max-w-3xl p-6 sm:p-10">
        <div className="flex flex-wrap items-start justify-between gap-6 border-b border-border pb-6">
          <div>
            <p className="text-[15px] font-semibold tracking-[0.14em]">{company.toUpperCase()}</p>
            <p className="mt-1 text-[11.5px] text-muted-foreground">Created with workbase</p>
            <div className="mt-4 space-y-1 text-[12.5px]">
              <p className="text-muted-foreground">Billed to</p>
              <p className="font-medium">{invoice.client_name || '—'}</p>
              {invoice.project_name && <p className="text-muted-foreground">{invoice.project_name}</p>}
            </div>
          </div>
          <div className="text-right">
            <p className="text-[11px] uppercase tracking-[0.14em] text-muted-foreground">Invoice</p>
            <p className="num text-[24px]">{invoice.number}</p>
            <div className="mt-4 space-y-1 text-[12px] text-muted-foreground">
              <p>Issued {longDate(invoice.issue_date)}</p>
              <p>Due {longDate(invoice.due_date)}</p>
            </div>
          </div>
        </div>

        <table className="mt-6 w-full text-left">
          <thead>
            <tr className="border-b border-border">
              <th className="pb-2 text-[10.5px] font-medium uppercase tracking-[0.12em] text-muted-foreground">
                Description
              </th>
              <th className="pb-2 text-right text-[10.5px] font-medium uppercase tracking-[0.12em] text-muted-foreground">
                Qty
              </th>
              <th className="pb-2 text-right text-[10.5px] font-medium uppercase tracking-[0.12em] text-muted-foreground">
                Rate
              </th>
              <th className="pb-2 text-right text-[10.5px] font-medium uppercase tracking-[0.12em] text-muted-foreground">
                Amount
              </th>
            </tr>
          </thead>
          <tbody className="divide-y divide-border">
            {(invoice.items || []).map((it, i) => (
              <tr key={i}>
                <td className="py-3 text-[13px]">{it.description}</td>
                <td className="py-3 text-right text-[12.5px] text-muted-foreground">{it.qty}</td>
                <td className="py-3 text-right text-[12.5px] text-muted-foreground">{money(it.rate, currency)}</td>
                <td className="num py-3 text-right text-[14px]">{money((Number(it.qty) || 0) * (Number(it.rate) || 0), currency)}</td>
              </tr>
            ))}
            {(invoice.items || []).length === 0 && (
              <tr>
                <td colSpan={4} className="py-4 text-[12.5px] text-muted-foreground">
                  No line items.
                </td>
              </tr>
            )}
          </tbody>
        </table>

        <div className="mt-6 ml-auto max-w-xs space-y-2 border-t border-border pt-4 text-[12.5px]">
          <div className="flex justify-between text-muted-foreground">
            <span>Subtotal</span>
            <span>{money(subtotal, currency)}</span>
          </div>
          <div className="flex justify-between text-muted-foreground">
            <span>Tax ({Number(invoice.tax_rate) || 0}%)</span>
            <span>{money(tax, currency)}</span>
          </div>
          <div className="flex items-center justify-between border-t border-border pt-2 text-[15px] font-medium">
            <span>Total due</span>
            <span className="num text-[22px]">{money(total, currency)}</span>
          </div>
        </div>

        {invoice.notes && (
          <div className="mt-8 rounded-xl bg-secondary/50 p-4">
            <p className="text-[10.5px] uppercase tracking-[0.12em] text-muted-foreground">Notes</p>
            <p className="mt-1 text-[12.5px] leading-relaxed">{invoice.notes}</p>
          </div>
        )}
      </div>

      <InvoiceDialog
        open={editOpen}
        invoice={invoice}
        clients={clients.items}
        projects={projects.items}
        nextNumber={invoice.number}
        onClose={() => setEditOpen(false)}
        onSaved={load}
      />
    </div>
  );
}
