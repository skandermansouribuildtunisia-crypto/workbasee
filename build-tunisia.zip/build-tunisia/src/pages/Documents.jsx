import { useMemo, useState } from 'react';
import { FileText, Plus, Search } from 'lucide-react';
import PageHeader from '@/components/common/PageHeader';
import EmptyState from '@/components/common/EmptyState';
import DocumentRow from '@/components/documents/DocumentRow';
import DocumentDialog from '@/components/documents/DocumentDialog';
import { useCollection } from '@/hooks/useCollection';
import { base44 } from '@/api/base44Client';

const STATUS_FILTERS = [
  { value: 'all', label: 'All' },
  { value: 'draft', label: 'Draft' },
  { value: 'sent', label: 'Sent' },
  { value: 'signed', label: 'Signed' },
  { value: 'archived', label: 'Archived' },
];

export default function Documents() {
  const documents = useCollection('Document', {}, { sort: '-created_date' });
  const clients = useCollection('Client', {}, { sort: 'name' });
  const projects = useCollection('Project', {}, { sort: 'name' });

  const [dialogOpen, setDialogOpen] = useState(false);
  const [editing, setEditing] = useState(null);
  const [status, setStatus] = useState('all');
  const [docType, setDocType] = useState('all');
  const [query, setQuery] = useState('');

  const visible = useMemo(() => {
    const q = query.trim().toLowerCase();
    return documents.items.filter((doc) => {
      if (status !== 'all' && doc.status !== status) return false;
      if (docType !== 'all' && doc.doc_type !== docType) return false;
      if (q && !`${doc.title} ${doc.client_name || ''} ${doc.project_name || ''}`.toLowerCase().includes(q)) return false;
      return true;
    });
  }, [documents.items, status, docType, query]);

  const signed = documents.items.filter((doc) => doc.status === 'signed').length;
  const pending = documents.items.filter((doc) => doc.status === 'sent').length;

  const openNew = () => {
    setEditing(null);
    setDialogOpen(true);
  };

  const download = async (doc) => {
    if (!doc.file_uri) return;
    const { signed_url } = await base44.integrations.Core.CreateFileSignedUrl({ file_uri: doc.file_uri });
    window.open(signed_url, '_blank', 'noopener');
  };

  const remove = async (doc) => {
    await base44.entities.Document.delete(doc.id);
    documents.reload();
  };

  return (
    <div>
      <PageHeader
        eyebrow="Paperwork"
        title="Documents & contracts"
        description={`${documents.items.length} documents · ${pending} out for signature · ${signed} signed`}
        actions={
          <button className="btn-ink" onClick={openNew}>
            <Plus className="h-4 w-4" /> Add document
          </button>
        }
      />

      <div className="mb-5 flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
        <div className="flex flex-wrap items-center gap-1.5">
          {STATUS_FILTERS.map((option) => (
            <button
              key={option.value}
              onClick={() => setStatus(option.value)}
              className={`rounded-full px-3.5 py-1.5 text-[11.5px] transition ${
                status === option.value
                  ? 'bg-primary text-primary-foreground'
                  : 'border border-border bg-card text-muted-foreground hover:text-foreground'
              }`}
            >
              {option.label}
            </button>
          ))}
          <select value={docType} onChange={(e) => setDocType(e.target.value)} className="field ml-1 w-auto py-2 capitalize">
            <option value="all">Every type</option>
            <option value="contract">Contract</option>
            <option value="proposal">Proposal</option>
            <option value="brief">Brief</option>
            <option value="report">Report</option>
            <option value="other">Other</option>
          </select>
        </div>
        <div className="relative">
          <Search className="pointer-events-none absolute left-3 top-1/2 h-3.5 w-3.5 -translate-y-1/2 text-muted-foreground" />
          <input
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            placeholder="Search documents…"
            className="field w-full py-2 pl-8 sm:w-60"
          />
        </div>
      </div>

      {documents.loading ? (
        <div className="space-y-2.5">
          {[0, 1, 2].map((i) => (
            <div key={i} className="h-[74px] animate-pulse rounded-2xl border border-border bg-card/60" />
          ))}
        </div>
      ) : documents.items.length === 0 ? (
        <EmptyState
          icon={FileText}
          title="No documents yet"
          description="Attach signed contracts, proposals and briefs so they stay with the client and project they belong to."
          action={
            <button className="btn-ink" onClick={openNew}>
              <Plus className="h-4 w-4" /> Add document
            </button>
          }
        />
      ) : (
        <div className="space-y-2.5">
          {visible.map((doc) => (
            <DocumentRow
              key={doc.id}
              doc={doc}
              onEdit={(item) => {
                setEditing(item);
                setDialogOpen(true);
              }}
              onDownload={download}
              onDelete={remove}
            />
          ))}
          {visible.length === 0 && (
            <p className="py-10 text-center text-[12.5px] text-muted-foreground">Nothing matches those filters.</p>
          )}
        </div>
      )}

      <DocumentDialog
        open={dialogOpen}
        document={editing}
        clients={clients.items}
        projects={projects.items}
        onClose={() => setDialogOpen(false)}
        onSaved={documents.reload}
      />
    </div>
  );
}
