import { useEffect, useState } from 'react';
import { format, parseISO } from 'date-fns';
import { CalendarCheck, CheckCircle2, Loader2 } from 'lucide-react';
import { base44 } from '@/api/base44Client';
import DayPicker, { nextWeekdays } from '@/components/booking/DayPicker';
import SlotPicker from '@/components/booking/SlotPicker';

const EMAIL_RE = /^[^@\s]+@[^@\s]+\.[^@\s]+$/;

export default function Book() {
  const [date, setDate] = useState(() => format(nextWeekdays(1)[0], 'yyyy-MM-dd'));
  const [slots, setSlots] = useState([]);
  const [loadingSlots, setLoadingSlots] = useState(true);
  const [time, setTime] = useState('');
  const [form, setForm] = useState({ name: '', email: '', phone: '', topic: '', notes: '' });
  const [sending, setSending] = useState(false);
  const [error, setError] = useState('');
  const [done, setDone] = useState(null);

  useEffect(() => {
    if (!date) return;
    setLoadingSlots(true);
    setTime('');
    base44.functions
      .invoke('bookingSlots', { date })
      .then((res) => setSlots(res.data?.slots || []))
      .catch(() => setSlots([]))
      .finally(() => setLoadingSlots(false));
  }, [date]);

  const set = (key) => (value) => setForm((f) => ({ ...f, [key]: value }));
  const ready = Boolean(time) && form.name.trim().length >= 2 && EMAIL_RE.test(form.email.trim());

  const submit = async () => {
    setError('');
    if (!time) {
      setError('Pick a time slot to continue.');
      return;
    }
    if (form.name.trim().length < 2) {
      setError('Add your name so we know who is coming.');
      return;
    }
    if (!EMAIL_RE.test(form.email.trim())) {
      setError('Add a valid email so we can confirm your call.');
      return;
    }
    setSending(true);
    try {
      const res = await base44.functions.invoke('bookingCreate', { ...form, date, time });
      setDone(res.data.booking);
    } catch (err) {
      setError(err?.response?.data?.error || 'The booking could not be sent. Please try again.');
    } finally {
      setSending(false);
    }
  };

  return (
    <div className="min-h-screen bg-background px-5 py-10 sm:py-12">
      <div className="mx-auto w-full max-w-3xl">
        <div className="mb-7 flex items-center gap-2">
          <span className="h-2.5 w-2.5 rounded-full bg-accent" />
          <span className="text-[12px] font-semibold uppercase tracking-[0.2em]">Book a call</span>
        </div>

        {done ? (
          <div className="surface p-7 sm:p-10">
            <span className="mb-4 flex h-12 w-12 items-center justify-center rounded-full bg-accent/30">
              <CheckCircle2 className="h-6 w-6" />
            </span>
            <h1 className="text-[26px] leading-tight tracking-[-0.02em]">Request received</h1>
            <p className="mt-2 max-w-md text-[13px] leading-relaxed text-muted-foreground">
              We will confirm {format(parseISO(done.date), 'EEEE d MMMM')} at {done.time} by email within one working
              day. It is already on our calendar.
            </p>
          </div>
        ) : (
          <>
            <h1 className="text-[30px] leading-[1.1] tracking-[-0.02em] sm:text-[38px]">
              Pick a time that works for you
            </h1>
            <p className="mt-2 text-[13px] text-muted-foreground">
              Weekdays, 30-minute calls. Choose a day and a time, then tell us who you are.
            </p>

            <div className="mt-7 grid gap-5 md:grid-cols-[1fr_1fr]">
              <div className="surface p-5">
                <DayPicker value={date} onChange={setDate} />
                <SlotPicker slots={slots} loading={loadingSlots} value={time} onChange={setTime} />
              </div>

              <div className="surface p-5">
                <p className="eyebrow mb-2">3 · Your details</p>

                <div className="mb-4 flex items-center gap-2 rounded-xl bg-secondary/70 px-3 py-2 text-[12px]">
                  <CalendarCheck className="h-3.5 w-3.5 shrink-0" />
                  <span className="truncate">
                    {time ? `${format(parseISO(date), 'EEE d MMM')} · ${time}` : 'Pick a day and time'}
                  </span>
                </div>

                <div className="space-y-3">
                  <label className="block">
                    <span className="mb-1.5 block text-[11.5px] font-medium uppercase tracking-[0.1em] text-muted-foreground">
                      Name
                    </span>
                    <input className="field" value={form.name} onChange={(e) => set('name')(e.target.value)} placeholder="Your name" />
                  </label>
                  <label className="block">
                    <span className="mb-1.5 block text-[11.5px] font-medium uppercase tracking-[0.1em] text-muted-foreground">
                      Email
                    </span>
                    <input
                      type="email"
                      className="field"
                      value={form.email}
                      onChange={(e) => set('email')(e.target.value)}
                      placeholder="name@company.com"
                    />
                  </label>
                  <label className="block">
                    <span className="mb-1.5 block text-[11.5px] font-medium uppercase tracking-[0.1em] text-muted-foreground">
                      Phone (optional)
                    </span>
                    <input className="field" value={form.phone} onChange={(e) => set('phone')(e.target.value)} placeholder="Phone number" />
                  </label>
                  <label className="block">
                    <span className="mb-1.5 block text-[11.5px] font-medium uppercase tracking-[0.1em] text-muted-foreground">
                      Topic
                    </span>
                    <input className="field" value={form.topic} onChange={(e) => set('topic')(e.target.value)} placeholder="What is this about?" />
                  </label>
                  <label className="block">
                    <span className="mb-1.5 block text-[11.5px] font-medium uppercase tracking-[0.1em] text-muted-foreground">
                      Notes (optional)
                    </span>
                    <textarea
                      className="field resize-none"
                      rows={2}
                      value={form.notes}
                      onChange={(e) => set('notes')(e.target.value)}
                      placeholder="Anything we should know beforehand"
                    />
                  </label>
                </div>

                {error && <p className="mt-3 text-[12px] text-destructive">{error}</p>}

                <button
                  className="btn-ink mt-4 w-full justify-center py-2.5 disabled:opacity-40"
                  onClick={submit}
                  disabled={sending || !ready}
                >
                  {sending ? <Loader2 className="h-4 w-4 animate-spin" /> : null}
                  {sending ? 'Sending…' : time ? `Request ${time}` : 'Request this slot'}
                </button>
                {!ready && !error && (
                  <p className="mt-2 text-center text-[11px] text-muted-foreground">
                    Pick a slot and add your name and email to send the request.
                  </p>
                )}
              </div>
            </div>
          </>
        )}

        <p className="mt-10 text-center text-[11px] text-muted-foreground">Powered by workbase</p>
      </div>
    </div>
  );
}
