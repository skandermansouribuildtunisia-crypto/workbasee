import { useEffect, useState } from 'react';
import { useParams } from 'react-router-dom';
import { base44 } from '@/api/base44Client';
import { money, longDate } from '@/lib/format';
import { CheckCircle2, CreditCard, Loader2, ShieldCheck } from 'lucide-react';

export default function PublicInvoice() {
  const { token } = useParams();
  const [data, setData] = useState(null);
  const [error, setError] = useState('');
  const [notice, setNotice] = useState('');
  const [paying, setPaying] = useState(false);

  const sessionId = new URLSearchParams(window.location.search).get('session_id') || '';

  const load = async () => {
    const res = await base44.functions.invoke('getPublicInvoice', { token });
    setData(res.data);
  };

  useEffect(() => {
    load().catch((e) => setError(e?.response?.data?.error || 'This invoice could not be loaded.'));
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [token]);

  useEffect(() => {
    if (!sessionId) return;
    let attempts = 0;
    let timer;
    const check = async () => {
      attempts += 1;
      try {
        const res = await base44.functions.invoke('invoicePaymentStatus', { token, session_id: sessionId });
        if (res.data?.paid) {
          await load();
          setNotice('Payment received. Thank you!');
          return;
        }
      } catch {
        // keep the page usable; the payment provider is still the source of truth
      }
      if (attempts < 4) timer = setTimeout(check, 2500);
      else setNotice('We are still confirming this payment with the bank. Refresh in a moment to see the receipt.');
    };
    check();
    return () => clearTimeout(timer);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [sessionId, token]);

  const startPayment = async () => {
    setError('');
    setNotice('');
    const isFramed = window.self !== window.top;
    const checkoutTab = isFramed ? window.open('', '_blank') : null;
    if (isFramed && !checkoutTab) {
      setError('Allow pop-ups in your browser to continue to the secure checkout.');
      return;
    }
    if (checkoutTab) checkoutTab.opener = null;

    setPaying(true);
    try {
      const res = await base44.functions.invoke('createInvoiceCheckout', { token });
      const url = res.data?.url;
      if (!url) throw new Error(res.data?.error || 'Checkout could not be created.');
      if (checkoutTab) checkoutTab.location.replace(url);
      else window.location.assign(url);
    } catch (e) {
      checkoutTab?.close();
      setError(e?.response?.data?.error || e.message || 'Checkout failed. Please try again.');
    } finally {
      setPaying(false);
    }
  };

  if (error && !data) {
    return (
      <div className="flex min-h-screen items-center justify-center bg-background px-5">
        <div className="surface max-w-md p-8 text-center">
          <h1 className="text-[20px] tracking-[-0.01em]">Invoice unavailable</h1>
          <p className="mt-2 text-[13px] text-muted-foreground">{error}</p>
        </div>
      </div>
    );
  }

  if (!data) {
    return (
      <div className="flex min-h-screen items-center justify-center bg-background">
        <div className="h-64 w-full max-w-2xl animate-pulse rounded-2xl border border-border bg-card/60" />
      </div>
    );
  }

  const { invoice, company } = data;
  const paid = invoice.status === 'paid';

  return (
    <div className="min-h-screen bg-background px-5 py-10 sm:py-16">
      <div className="mx-auto w-full max-w-2xl">
        <div className="mb-6 flex items-center justify-between">
          <p className="text-[13px] font-semibold tracking-[0.18em]">{String(company).toUpperCase()}</p>
          <span className="text-[11px] uppercase tracking-[0.14em] text-muted-foreground">Secure invoice</span>
        </div>

        <div className="surface p-6 sm:p-9">
          <div className="flex flex-wrap items-start justify-between gap-5 border-b border-border pb-6">
            <div>
              <p className="text-[11px] uppercase tracking-[0.14em] text-muted-foreground">Invoice</p>
              <p className="num text-[26px] leading-tight">{invoice.number}</p>
              <p className="mt-2 text-[12.5px] text-muted-foreground">Billed to {invoice.client_name || 'customer'}</p>
            </div>
            <div className="text-right text-[12px] text-muted-foreground">
              <p>Issued {longDate(invoice.issue_date)}</p>
              <p>Due {longDate(invoice.due_date)}</p>
              <p className="mt-2 capitalize">{invoice.status}</p>
            </div>
          </div>

          <table className="mt-5 w-full text-left">
            <thead>
              <tr className="border-b border-border">
                <th className="pb-2 text-[10.5px] font-medium uppercase tracking-[0.12em] text-muted-foreground">Description</th>
                <th className="pb-2 text-right text-[10.5px] font-medium uppercase tracking-[0.12em] text-muted-foreground">Qty</th>
                <th className="pb-2 text-right text-[10.5px] font-medium uppercase tracking-[0.12em] text-muted-foreground">Amount</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-border">
              {invoice.items.map((it, i) => (
                <tr key={i}>
                  <td className="py-3 text-[13px]">{it.description}</td>
                  <td className="py-3 text-right text-[12.5px] text-muted-foreground">{it.qty}</td>
                  <td className="num py-3 text-right text-[14px]">{money(it.qty * it.rate, invoice.currency)}</td>
                </tr>
              ))}
            </tbody>
          </table>

          <div className="mt-5 ml-auto max-w-xs space-y-2 border-t border-border pt-4 text-[12.5px]">
            <div className="flex justify-between text-muted-foreground">
              <span>Subtotal</span>
              <span>{money(invoice.subtotal, invoice.currency)}</span>
            </div>
            <div className="flex justify-between text-muted-foreground">
              <span>Tax ({invoice.tax_rate}%)</span>
              <span>{money(invoice.tax, invoice.currency)}</span>
            </div>
            <div className="flex items-center justify-between border-t border-border pt-2 text-[15px] font-medium">
              <span>{paid ? 'Paid' : 'Total due'}</span>
              <span className="num text-[22px]">{money(invoice.total, invoice.currency)}</span>
            </div>
          </div>

          {notice && (
            <div className="mt-6 flex items-start gap-2 rounded-xl bg-secondary/60 p-3.5 text-[12.5px]">
              <CheckCircle2 className="mt-0.5 h-4 w-4 text-foreground" />
              <span>{notice}</span>
            </div>
          )}
          {error && <p className="mt-4 text-[12.5px] text-destructive">{error}</p>}

          <div className="mt-7">
            {paid ? (
              <div className="flex items-center gap-2 rounded-xl bg-accent/25 px-4 py-3 text-[13px] font-medium">
                <CheckCircle2 className="h-4 w-4" /> This invoice is paid in full.
                {invoice.paid_at ? <span className="text-muted-foreground"> · {longDate(invoice.paid_at.slice(0, 10))}</span> : null}
              </div>
            ) : (
              <>
                <button className="btn-lime w-full py-3 text-[14px]" onClick={startPayment} disabled={paying}>
                  {paying ? <Loader2 className="h-4 w-4 animate-spin" /> : <CreditCard className="h-4 w-4" />}
                  {paying ? 'Opening secure checkout…' : `Pay ${money(invoice.total, invoice.currency)}`}
                </button>
                <p className="mt-3 flex items-center justify-center gap-1.5 text-[11.5px] text-muted-foreground">
                  <ShieldCheck className="h-3.5 w-3.5" /> Card payment processed securely by Stripe
                </p>
              </>
            )}
          </div>

          {invoice.notes && (
            <div className="mt-6 rounded-xl bg-secondary/50 p-4">
              <p className="text-[10.5px] uppercase tracking-[0.12em] text-muted-foreground">Notes</p>
              <p className="mt-1 text-[12.5px] leading-relaxed">{invoice.notes}</p>
            </div>
          )}
        </div>

        <p className="mt-6 text-center text-[11px] text-muted-foreground">Powered by workbase</p>
      </div>
    </div>
  );
}
