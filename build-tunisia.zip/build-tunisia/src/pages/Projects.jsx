import { useState } from 'react';
import { Link } from 'react-router-dom';
import { FolderKanban, Plus } from 'lucide-react';
import { motion } from 'framer-motion';
import PageHeader from '@/components/common/PageHeader';
import EmptyState from '@/components/common/EmptyState';
import ProjectDialog from '@/components/projects/ProjectDialog';
import { useCollection } from '@/hooks/useCollection';
import { useWorkspace } from '@/lib/workspace';
import { projectFinance } from '@/lib/derive';
import { money, shortDate } from '@/lib/format';

const tabs = [
  { value: 'all', label: 'All' },
  { value: 'active', label: 'Active' },
  { value: 'planning', label: 'Planning' },
  { value: 'on_hold', label: 'On hold' },
  { value: 'completed', label: 'Completed' },
];

export default function Projects() {
  const { currency } = useWorkspace();
  const projects = useCollection('Project', {}, { sort: '-created_date' });
  const clients = useCollection('Client', {}, { sort: 'name' });
  const tasks = useCollection('Task');
  const expenses = useCollection('Expense');
  const invoices = useCollection('Invoice');
  const [tab, setTab] = useState('all');
  const [open, setOpen] = useState(false);

  const filtered = projects.items.filter((p) => tab === 'all' || p.status === tab);
  const totalBudget = projects.items.reduce((s, p) => s + (Number(p.budget) || 0), 0);

  return (
    <div>
      <PageHeader
        eyebrow="Delivery"
        title="Projects"
        description={`${projects.items.length} projects · ${money(totalBudget, currency, true)} contracted`}
        actions={
          <button className="btn-ink" onClick={() => setOpen(true)}>
            <Plus className="h-4 w-4" /> New project
          </button>
        }
      />

      <div className="mb-6 flex flex-wrap gap-1.5">
        {tabs.map((t) => (
          <button
            key={t.value}
            onClick={() => setTab(t.value)}
            className={`rounded-full px-3.5 py-1.5 text-[12px] font-medium transition-all ${
              tab === t.value
                ? 'bg-primary text-primary-foreground'
                : 'border border-border bg-card text-muted-foreground hover:text-foreground'
            }`}
          >
            {t.label}
          </button>
        ))}
      </div>

      {projects.loading ? (
        <div className="grid grid-cols-1 gap-4 lg:grid-cols-2">
          {[0, 1, 2, 3].map((i) => (
            <div key={i} className="h-48 animate-pulse rounded-2xl border border-border bg-card/60" />
          ))}
        </div>
      ) : filtered.length === 0 ? (
        <EmptyState
          icon={FolderKanban}
          title={projects.items.length ? 'No projects in this view' : 'No projects yet'}
          description="Every project carries its budget, tasks, expenses and profitability."
          action={
            <button className="btn-ink" onClick={() => setOpen(true)}>
              <Plus className="h-4 w-4" /> New project
            </button>
          }
        />
      ) : (
        <div className="grid grid-cols-1 gap-4 lg:grid-cols-2">
          {filtered.map((p, i) => {
            const f = projectFinance(p, expenses.items, invoices.items, tasks.items);
            const over = p.budget > 0 && f.spent > p.budget;
            return (
              <motion.div
                key={p.id}
                initial={{ opacity: 0, y: 14 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: i * 0.05, duration: 0.4 }}
              >
                <Link
                  to={`/projects/${p.id}`}
                  className="surface block p-5 transition-all duration-300 hover:-translate-y-0.5 hover:shadow-[0_1px_2px_rgba(20,21,15,0.05),0_24px_48px_-32px_rgba(20,21,15,0.5)] sm:p-6"
                >
                  <div className="flex items-start justify-between gap-3">
                    <div className="min-w-0">
                      <p className="truncate text-[16px] font-medium tracking-[-0.01em]">{p.name}</p>
                      <p className="mt-0.5 text-[12px] text-muted-foreground">{p.client_name || 'Internal'}</p>
                    </div>
                    <span className="shrink-0 rounded-full bg-secondary px-2.5 py-1 text-[10.5px] font-medium capitalize text-muted-foreground">
                      {p.status.replace('_', ' ')}
                    </span>
                  </div>

                  <div className="mt-5 grid grid-cols-3 gap-3">
                    <div>
                      <p className="text-[10px] uppercase tracking-[0.12em] text-muted-foreground">Budget</p>
                      <p className="num text-[15px]">{money(p.budget, currency, true)}</p>
                    </div>
                    <div>
                      <p className="text-[10px] uppercase tracking-[0.12em] text-muted-foreground">Spent</p>
                      <p className={`num text-[15px] ${over ? 'text-destructive' : ''}`}>
                        {money(f.spent, currency, true)}
                      </p>
                    </div>
                    <div>
                      <p className="text-[10px] uppercase tracking-[0.12em] text-muted-foreground">Profit</p>
                      <p className="num text-[15px]">{money(f.profit, currency, true)}</p>
                    </div>
                  </div>

                  <div className="mt-4">
                    <div className="mb-1.5 flex items-center justify-between text-[11px] text-muted-foreground">
                      <span>
                        {f.doneTasks}/{f.totalTasks} tasks done
                      </span>
                      <span>Due {shortDate(p.due_date)}</span>
                    </div>
                    <div className="h-1.5 w-full overflow-hidden rounded-full bg-secondary">
                      <motion.div
                        className="h-full rounded-full bg-accent"
                        initial={{ width: 0 }}
                        animate={{ width: `${f.progress}%` }}
                        transition={{ duration: 0.9, ease: [0.22, 1, 0.36, 1] }}
                      />
                    </div>
                  </div>
                </Link>
              </motion.div>
            );
          })}
        </div>
      )}

      <ProjectDialog open={open} onClose={() => setOpen(false)} clients={clients.items} onSaved={projects.reload} />
    </div>
  );
}
