import { useRef, useState } from 'react';
import { motion } from 'framer-motion';
import { ArrowUp, Sparkles } from 'lucide-react';
import { base44 } from '@/api/base44Client';
import PageHeader from '@/components/common/PageHeader';

const suggestions = [
  'Which projects are making the most profit?',
  'Which customers have unpaid invoices?',
  'How much did we spend this month?',
  'What should I prioritise tomorrow?',
];

export default function Assistant() {
  const [messages, setMessages] = useState([
    {
      role: 'assistant',
      text: 'I can read your workspace — customers, projects, tasks, invoices and expenses. Ask me where the money is going.',
    },
  ]);
  const [input, setInput] = useState('');
  const [busy, setBusy] = useState(false);
  const scroller = useRef(null);

  const scrollDown = () => {
    requestAnimationFrame(() => {
      scroller.current?.scrollTo({ top: scroller.current.scrollHeight, behavior: 'smooth' });
    });
  };

  const send = async (text) => {
    const question = (text ?? input).trim();
    if (!question || busy) return;
    setInput('');
    setMessages((m) => [...m, { role: 'user', text: question }]);
    setBusy(true);
    scrollDown();
    try {
      const res = await base44.functions.invoke('businessAssistant', { question });
      const answer = res?.data?.answer || res?.data?.error || 'I could not read your data just now.';
      setMessages((m) => [...m, { role: 'assistant', text: answer }]);
    } catch (err) {
      setMessages((m) => [
        ...m,
        { role: 'assistant', text: `I could not reach the analysis service. ${err?.message || ''}`.trim() },
      ]);
    }
    setBusy(false);
    scrollDown();
  };

  return (
    <div>
      <PageHeader
        eyebrow="Intelligence"
        title="AI business assistant"
        description="Connected to your workspace data — answers grounded in your own numbers."
      />

      <div className="grid grid-cols-1 gap-6 xl:grid-cols-4">
        <div className="surface flex h-[68vh] min-h-[480px] flex-col xl:col-span-3">
          <div ref={scroller} className="flex-1 space-y-4 overflow-y-auto p-5 sm:p-6">
            {messages.map((m, i) => (
              <motion.div
                key={i}
                initial={{ opacity: 0, y: 8 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.3 }}
                className={`flex ${m.role === 'user' ? 'justify-end' : 'justify-start'}`}
              >
                <div
                  className={`max-w-[85%] rounded-2xl px-4 py-3 text-[13px] leading-relaxed ${
                    m.role === 'user'
                      ? 'bg-primary text-primary-foreground'
                      : 'border border-border bg-secondary/50 text-foreground'
                  }`}
                >
                  {m.role === 'assistant' && (
                    <p className="mb-1 flex items-center gap-1.5 text-[10px] uppercase tracking-[0.14em] text-muted-foreground">
                      <Sparkles className="h-3 w-3" /> workbase assistant
                    </p>
                  )}
                  <p className="whitespace-pre-wrap">{m.text}</p>
                </div>
              </motion.div>
            ))}
            {busy && (
              <div className="flex items-center gap-2 text-[12px] text-muted-foreground">
                <span className="flex gap-1">
                  {[0, 1, 2].map((i) => (
                    <motion.span
                      key={i}
                      className="h-1.5 w-1.5 rounded-full bg-muted-foreground"
                      animate={{ opacity: [0.25, 1, 0.25] }}
                      transition={{ duration: 1, repeat: Infinity, delay: i * 0.18 }}
                    />
                  ))}
                </span>
                Reading your workspace…
              </div>
            )}
          </div>

          <div className="border-t border-border p-4">
            <div className="flex items-end gap-2">
              <textarea
                rows={1}
                className="field max-h-32 flex-1 resize-none"
                placeholder="Ask about profit, cash, customers…"
                value={input}
                onChange={(e) => setInput(e.target.value)}
                onKeyDown={(e) => {
                  if (e.key === 'Enter' && !e.shiftKey) {
                    e.preventDefault();
                    send();
                  }
                }}
              />
              <button
                className="btn-ink h-[42px] w-[42px] shrink-0 rounded-full p-0"
                onClick={() => send()}
                disabled={busy || !input.trim()}
                aria-label="Send question"
              >
                <ArrowUp className="h-4 w-4" />
              </button>
            </div>
          </div>
        </div>

        <div className="space-y-3">
          <p className="eyebrow">Try asking</p>
          {suggestions.map((s) => (
            <button
              key={s}
              onClick={() => send(s)}
              disabled={busy}
              className="w-full rounded-xl border border-border bg-card p-3.5 text-left text-[12.5px] leading-snug transition-all duration-200 hover:-translate-y-0.5 hover:shadow-md disabled:opacity-50"
            >
              {s}
            </button>
          ))}
          <p className="px-1 pt-2 text-[11px] leading-relaxed text-muted-foreground">
            Answers are generated from your recorded customers, projects, tasks, invoices and expenses — not from
            external sources.
          </p>
        </div>
      </div>
    </div>
  );
}
