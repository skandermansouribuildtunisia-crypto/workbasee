import { useMemo, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import {
  addMonths,
  eachDayOfInterval,
  endOfMonth,
  endOfWeek,
  format,
  isBefore,
  parseISO,
  startOfDay,
  startOfMonth,
  startOfWeek,
  subMonths,
} from 'date-fns';
import { ChevronLeft, ChevronRight, Plus } from 'lucide-react';
import PageHeader from '@/components/common/PageHeader';
import CalendarMonth from '@/components/calendar/CalendarMonth';
import DayAgenda from '@/components/calendar/DayAgenda';
import TaskDialog from '@/components/tasks/TaskDialog';
import { useCollection } from '@/hooks/useCollection';

function toDate(value) {
  if (!value) return null;
  const date = String(value).length <= 10 ? parseISO(String(value)) : new Date(value);
  return Number.isNaN(date.getTime()) ? null : date;
}

export default function Calendar() {
  const navigate = useNavigate();
  const projects = useCollection('Project');
  const tasks = useCollection('Task');
  const bookings = useCollection('Booking');
  const [month, setMonth] = useState(() => startOfMonth(new Date()));
  const [selected, setSelected] = useState(() => new Date());
  const [dialogOpen, setDialogOpen] = useState(false);
  const [editingTask, setEditingTask] = useState(null);

  const events = useMemo(() => {
    const list = [];

    projects.items.forEach((project) => {
      if (project.status === 'completed') return;
      const due = toDate(project.due_date);
      if (due) {
        list.push({
          id: `p-${project.id}`,
          kind: 'project',
          title: project.name,
          date: due,
          meta: project.client_name || '',
          projectId: project.id,
        });
      }
      const start = toDate(project.start_date);
      if (start) {
        list.push({
          id: `ps-${project.id}`,
          kind: 'kickoff',
          title: `${project.name} begins`,
          date: start,
          meta: project.client_name || '',
          projectId: project.id,
        });
      }
      (project.milestones || []).forEach((milestone, index) => {
        const date = toDate(milestone?.due_date);
        if (!date || milestone?.done) return;
        list.push({
          id: `m-${project.id}-${index}`,
          kind: 'milestone',
          title: milestone.title || 'Milestone',
          date,
          meta: project.name,
          projectId: project.id,
        });
      });
    });

    tasks.items.forEach((task) => {
      if (task.status === 'done') return;
      const due = toDate(task.due_date);
      if (!due) return;
      list.push({
        id: `t-${task.id}`,
        kind: 'task',
        title: task.title,
        date: due,
        meta: task.project_name || task.assignee || '',
        task,
      });
    });

    bookings.items.forEach((booking) => {
      if (booking.status === 'cancelled') return;
      const booked = toDate(booking.date);
      if (!booked) return;
      list.push({
        id: `b-${booking.id}`,
        kind: 'booking',
        title: `${booking.time} · ${booking.name}`,
        date: booked,
        meta: [booking.topic, booking.status === 'requested' ? 'Awaiting confirmation' : 'Confirmed']
          .filter(Boolean)
          .join(' · '),
        bookingId: booking.id,
      });
    });

    return list.sort((a, b) => a.date - b.date);
  }, [projects.items, tasks.items, bookings.items]);

  const eventsByDay = useMemo(() => {
    const map = {};
    events.forEach((event) => {
      const key = format(event.date, 'yyyy-MM-dd');
      if (!map[key]) map[key] = [];
      map[key].push(event);
    });
    return map;
  }, [events]);

  const days = useMemo(
    () =>
      eachDayOfInterval({
        start: startOfWeek(startOfMonth(month)),
        end: endOfWeek(endOfMonth(month)),
      }),
    [month],
  );

  const selectedEvents = eventsByDay[format(selected, 'yyyy-MM-dd')] || [];
  const today = startOfDay(new Date());
  const overdue = events.filter((event) => isBefore(event.date, today)).length;
  const activeProjects = projects.items.filter((project) => project.status !== 'completed').length;

  const openEvent = (event) => {
    if (event.kind === 'booking') {
      navigate('/bookings');
      return;
    }
    if (event.kind === 'task') {
      setEditingTask(event.task);
      setDialogOpen(true);
      return;
    }
    if (event.projectId) navigate(`/projects/${event.projectId}`);
  };

  return (
    <div>
      <PageHeader
        eyebrow="Planning"
        title="Calendar"
        description={`${activeProjects} live projects · ${events.length} upcoming commitments · ${overdue} past due`}
        actions={
          <button
            className="btn-ink"
            onClick={() => {
              setEditingTask(null);
              setDialogOpen(true);
            }}
          >
            <Plus className="h-4 w-4" /> New task
          </button>
        }
      />

      <div className="surface mb-4 flex flex-wrap items-center justify-between gap-3 px-3 py-2.5">
        <div className="flex items-center gap-1.5">
          <button
            onClick={() => setMonth(subMonths(month, 1))}
            className="rounded-full p-1.5 text-muted-foreground transition hover:bg-secondary hover:text-foreground"
            aria-label="Previous month"
          >
            <ChevronLeft className="h-4 w-4" />
          </button>
          <span className="min-w-[150px] text-center text-[13.5px] font-medium tracking-[-0.01em]">
            {format(month, 'MMMM yyyy')}
          </span>
          <button
            onClick={() => setMonth(addMonths(month, 1))}
            className="rounded-full p-1.5 text-muted-foreground transition hover:bg-secondary hover:text-foreground"
            aria-label="Next month"
          >
            <ChevronRight className="h-4 w-4" />
          </button>
          <button
            onClick={() => {
              setMonth(startOfMonth(new Date()));
              setSelected(new Date());
            }}
            className="ml-1 rounded-full border border-border px-3 py-1 text-[11.5px] text-muted-foreground transition hover:text-foreground"
          >
            Today
          </button>
        </div>

        <div className="flex flex-wrap items-center gap-3 text-[10.5px] text-muted-foreground">
          <span className="flex items-center gap-1.5">
            <span className="h-1.5 w-1.5 rounded-full bg-primary" /> Project deadline
          </span>
          <span className="flex items-center gap-1.5">
            <span className="h-1.5 w-1.5 rounded-full bg-chart-4" /> Milestone
          </span>
          <span className="flex items-center gap-1.5">
            <span className="h-1.5 w-1.5 rounded-full bg-chart-1" /> Task due
          </span>
          <span className="flex items-center gap-1.5">
            <span className="h-1.5 w-1.5 rounded-full bg-chart-3" /> Client call
          </span>
          <span className="flex items-center gap-1.5">
            <span className="h-1.5 w-1.5 rounded-full bg-destructive" /> High priority
          </span>
        </div>
      </div>

      <div className="grid grid-cols-1 gap-5 xl:grid-cols-[1fr_330px]">
        <CalendarMonth
          days={days}
          month={month}
          eventsByDay={eventsByDay}
          selected={selected}
          onSelect={setSelected}
        />
        <DayAgenda date={selected} events={selectedEvents} onOpen={openEvent} />
      </div>

      <TaskDialog
        open={dialogOpen}
        task={editingTask}
        projects={projects.items}
        defaultDueDate={format(selected, 'yyyy-MM-dd')}
        onClose={() => setDialogOpen(false)}
        onSaved={() => {
          tasks.reload();
          projects.reload();
        }}
      />
    </div>
  );
}
