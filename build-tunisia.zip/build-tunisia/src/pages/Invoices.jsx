import { useState } from 'react';
import { Link } from 'react-router-dom';
import { Plus, Receipt } from 'lucide-react';
import PageHeader from '@/components/common/PageHeader';
import StatTile from '@/components/common/StatTile';
import EmptyState from '@/components/common/EmptyState';
import InvoiceDialog from '@/components/invoices/InvoiceDialog';
import { useCollection } from '@/hooks/useCollection';
import { useWorkspace } from '@/lib/workspace';
import { isOverdue } from '@/lib/derive';
import { money, shortDate } from '@/lib/format';

const tabs = ['all', 'draft', 'sent', 'overdue', 'paid'];

const statusStyle = {
  paid: 'bg-accent/30 text-foreground',
  sent: 'bg-chart-4/15 text-chart-4',
  overdue: 'bg-destructive/10 text-destructive',
  draft: 'bg-secondary text-muted-foreground',
};

export default function Invoices() {
  const { currency } = useWorkspace();
  const invoices = useCollection('Invoice', {}, { sort: '-issue_date' });
  const clients = useCollection('Client', {}, { sort: 'name' });
  const projects = useCollection('Project', {}, { sort: 'name' });
  const [tab, setTab] = useState('all');
  const [open, setOpen] = useState(false);

  const year = new Date().getFullYear();
  const nextNumber = `INV-${year}-${String(invoices.items.length + 1).padStart(3, '0')}`;

  const filtered = invoices.items.filter((i) => tab === 'all' || i.status === tab);

  const outstanding = invoices.items
    .filter((i) => i.status !== 'paid')
    .reduce((s, i) => s + (Number(i.total) || 0), 0);
  const paidThisYear = invoices.items
    .filter((i) => i.status === 'paid' && new Date(i.issue_date).getFullYear() === year)
    .reduce((s, i) => s + (Number(i.total) || 0), 0);
  const overdueCount = invoices.items.filter(isOverdue).length;

  return (
    <div>
      <PageHeader
        eyebrow="Billing"
        title="Invoices"
        description="Quotes, invoices and payment status — with a profit view you can trust."
        actions={
          <button className="btn-ink" onClick={() => setOpen(true)}>
            <Plus className="h-4 w-4" /> New invoice
          </button>
        }
      />

      <div className="grid grid-cols-1 gap-4 sm:grid-cols-3">
        <StatTile label="Outstanding" value={money(outstanding, currency)} hint="Sent, unpaid or overdue" />
        <StatTile label={`Paid in ${year}`} value={money(paidThisYear, currency, true)} hint="Cash collected" />
        <StatTile label="Overdue" value={String(overdueCount)} hint="Past the due date" tone={overdueCount ? 'negative' : 'default'} />
      </div>

      <div className="mb-5 mt-6 flex flex-wrap gap-1.5">
        {tabs.map((t) => (
          <button
            key={t}
            onClick={() => setTab(t)}
            className={`rounded-full px-3.5 py-1.5 text-[12px] font-medium capitalize transition-all ${
              tab === t
                ? 'bg-primary text-primary-foreground'
                : 'border border-border bg-card text-muted-foreground hover:text-foreground'
            }`}
          >
            {t}
          </button>
        ))}
      </div>

      {invoices.loading ? (
        <div className="h-64 animate-pulse rounded-2xl border border-border bg-card/60" />
      ) : filtered.length === 0 ? (
        <EmptyState
          icon={Receipt}
          title={invoices.items.length ? 'No invoices in this view' : 'No invoices yet'}
          description="Create an invoice, mark it paid, and your dashboard, cash flow and reports update automatically."
          action={
            <button className="btn-ink" onClick={() => setOpen(true)}>
              <Plus className="h-4 w-4" /> New invoice
            </button>
          }
        />
      ) : (
        <div className="surface overflow-hidden">
          <div className="overflow-x-auto">
            <table className="w-full min-w-[680px] text-left">
              <thead>
                <tr className="border-b border-border bg-secondary/40">
                  {['Invoice', 'Customer', 'Project', 'Issued', 'Due', 'Status', 'Amount'].map((h) => (
                    <th
                      key={h}
                      className={`px-5 py-3 text-[10.5px] font-medium uppercase tracking-[0.12em] text-muted-foreground ${
                        h === 'Amount' ? 'text-right' : ''
                      }`}
                    >
                      {h}
                    </th>
                  ))}
                </tr>
              </thead>
              <tbody className="divide-y divide-border">
                {filtered.map((inv) => {
                  const late = isOverdue(inv);
                  return (
                    <tr key={inv.id} className="row-hover">
                      <td className="px-5 py-3.5 text-[12.5px] font-medium">
                        <Link to={`/invoices/${inv.id}`} className="hover:underline">
                          {inv.number}
                        </Link>
                      </td>
                      <td className="px-5 py-3.5 text-[13px]">{inv.client_name || '—'}</td>
                      <td className="px-5 py-3.5 text-[12px] text-muted-foreground">{inv.project_name || '—'}</td>
                      <td className="px-5 py-3.5 text-[12px] text-muted-foreground">{shortDate(inv.issue_date)}</td>
                      <td className={`px-5 py-3.5 text-[12px] ${late ? 'text-destructive' : 'text-muted-foreground'}`}>
                        {shortDate(inv.due_date)}
                      </td>
                      <td className="px-5 py-3.5">
                        <span
                          className={`rounded-full px-2.5 py-1 text-[10.5px] font-medium capitalize ${
                            statusStyle[inv.status] || statusStyle.draft
                          }`}
                        >
                          {inv.status}
                        </span>
                      </td>
                      <td className="num px-5 py-3.5 text-right text-[15px]">{money(inv.total, currency)}</td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </div>
      )}

      <InvoiceDialog
        open={open}
        onClose={() => setOpen(false)}
        clients={clients.items}
        projects={projects.items}
        nextNumber={nextNumber}
        onSaved={invoices.reload}
      />
    </div>
  );
}
