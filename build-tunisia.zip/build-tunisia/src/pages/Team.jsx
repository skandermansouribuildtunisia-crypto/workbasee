import { useState } from 'react';
import { Clock, Trash2, UserPlus } from 'lucide-react';
import PageHeader from '@/components/common/PageHeader';
import EmptyState from '@/components/common/EmptyState';
import MemberCard from '@/components/team/MemberCard';
import MemberDialog from '@/components/team/MemberDialog';
import TimeEntryDialog from '@/components/team/TimeEntryDialog';
import { useCollection } from '@/hooks/useCollection';
import { base44 } from '@/api/base44Client';
import { useWorkspace } from '@/lib/workspace';
import { money, num, shortDate } from '@/lib/format';

export default function Team() {
  const { currency } = useWorkspace();
  const members = useCollection('TeamMember', {}, { sort: 'name' });
  const entries = useCollection('TimeEntry', {}, { sort: '-date' });
  const projects = useCollection('Project', {}, { sort: 'name' });
  const tasks = useCollection('Task', {}, { sort: 'title' });

  const [memberOpen, setMemberOpen] = useState(false);
  const [editing, setEditing] = useState(null);
  const [timeOpen, setTimeOpen] = useState(false);
  const [timeMember, setTimeMember] = useState(null);

  const monthKey = new Date().toISOString().slice(0, 7);
  const monthEntries = entries.items.filter((entry) => (entry.date || '').startsWith(monthKey));
  const hoursFor = (member) =>
    monthEntries
      .filter((entry) => entry.member_id === member.id || (!entry.member_id && entry.member_name === member.name))
      .reduce((sum, entry) => sum + (Number(entry.hours) || 0), 0);
  const valueFor = (member) =>
    monthEntries
      .filter((entry) => entry.member_id === member.id || (!entry.member_id && entry.member_name === member.name))
      .reduce((sum, entry) => sum + (Number(entry.hours) || 0) * (Number(entry.hourly_rate) || 0), 0);
  const totalHours = monthEntries.reduce((sum, entry) => sum + (Number(entry.hours) || 0), 0);
  const billableValue = monthEntries
    .filter((entry) => entry.billable !== false)
    .reduce((sum, entry) => sum + (Number(entry.hours) || 0) * (Number(entry.hourly_rate) || 0), 0);

  const openNew = () => {
    setEditing(null);
    setMemberOpen(true);
  };

  const removeMember = async (member) => {
    await base44.entities.TeamMember.delete(member.id);
    members.reload();
  };

  const removeEntry = async (entry) => {
    await base44.entities.TimeEntry.delete(entry.id);
    entries.reload();
  };

  return (
    <div>
      <PageHeader
        eyebrow="People"
        title="Team & time"
        description={`${members.items.length} people · ${num(totalHours)} hours this month · ${money(billableValue, currency, true)} billed work`}
        actions={
          <>
            <button
              className="btn-ghost"
              onClick={() => {
                setTimeMember(null);
                setTimeOpen(true);
              }}
              disabled={members.items.length === 0}
            >
              <Clock className="h-4 w-4" /> Log time
            </button>
            <button className="btn-ink" onClick={openNew}>
              <UserPlus className="h-4 w-4" /> Add member
            </button>
          </>
        }
      />

      {members.loading ? (
        <div className="grid gap-3 sm:grid-cols-2 xl:grid-cols-3">
          {[0, 1, 2].map((i) => (
            <div key={i} className="h-[118px] animate-pulse rounded-2xl border border-border bg-card/60" />
          ))}
        </div>
      ) : members.items.length === 0 ? (
        <EmptyState
          icon={UserPlus}
          title="No team members yet"
          description="Add the people who deliver the work, then log their hours against projects."
          action={
            <button className="btn-ink" onClick={openNew}>
              <UserPlus className="h-4 w-4" /> Add member
            </button>
          }
        />
      ) : (
        <div className="grid gap-3 sm:grid-cols-2 xl:grid-cols-3">
          {members.items.map((member) => (
            <MemberCard
              key={member.id}
              member={member}
              hours={hoursFor(member)}
              value={valueFor(member)}
              currency={currency}
              onEdit={() => {
                setEditing(member);
                setMemberOpen(true);
              }}
              onDelete={() => removeMember(member)}
              onLog={() => {
                setTimeMember(member.id);
                setTimeOpen(true);
              }}
            />
          ))}
        </div>
      )}

      <div className="surface mt-6 p-5">
        <div className="mb-4 flex flex-wrap items-baseline justify-between gap-2">
          <h2 className="text-[17px] tracking-[-0.01em]">Time log</h2>
          <p className="text-[11.5px] text-muted-foreground">
            {num(totalHours)} h this month · {entries.items.length} entries
          </p>
        </div>

        {entries.items.length === 0 ? (
          <p className="rounded-xl border border-dashed border-border px-4 py-10 text-center text-[12.5px] text-muted-foreground">
            No hours logged yet.
          </p>
        ) : (
          <div className="-mx-2 divide-y divide-border">
            {entries.items.slice(0, 40).map((entry) => (
              <div key={entry.id} className="flex items-center gap-3 px-2 py-2.5">
                <span className="w-14 shrink-0 text-[11.5px] text-muted-foreground">{shortDate(entry.date)}</span>
                <span className="min-w-0 flex-1">
                  <span className="block truncate text-[12.5px] font-medium">{entry.member_name}</span>
                  <span className="block truncate text-[11px] text-muted-foreground">
                    {entry.project_name || 'Internal'}
                    {entry.task_title ? ` · ${entry.task_title}` : ''}
                    {entry.notes ? ` · ${entry.notes}` : ''}
                  </span>
                </span>
                <span className="num shrink-0 text-[12.5px]">{num(entry.hours)} h</span>
                <span
                  className={`shrink-0 rounded-full px-2 py-0.5 text-[10px] ${
                    entry.billable === false ? 'bg-secondary text-muted-foreground' : 'bg-accent/30 text-foreground'
                  }`}
                >
                  {entry.billable === false ? 'Internal' : 'Billable'}
                </span>
                <span className="num w-16 shrink-0 text-right text-[12px] text-muted-foreground">
                  {money((Number(entry.hours) || 0) * (Number(entry.hourly_rate) || 0), currency, true)}
                </span>
                <button
                  onClick={() => removeEntry(entry)}
                  className="rounded-full p-1.5 text-muted-foreground transition hover:bg-secondary hover:text-destructive"
                  aria-label="Delete time entry"
                >
                  <Trash2 className="h-3.5 w-3.5" />
                </button>
              </div>
            ))}
          </div>
        )}
      </div>

      <MemberDialog
        open={memberOpen}
        member={editing}
        onClose={() => setMemberOpen(false)}
        onSaved={members.reload}
      />
      <TimeEntryDialog
        open={timeOpen}
        members={members.items}
        projects={projects.items}
        tasks={tasks.items}
        defaultMemberId={timeMember}
        onClose={() => setTimeOpen(false)}
        onSaved={entries.reload}
      />
    </div>
  );
}
