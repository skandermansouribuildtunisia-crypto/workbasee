import { useMemo, useRef, useState } from 'react';
import { DragDropContext } from '@hello-pangea/dnd';
import { motion } from 'framer-motion';
import { ListChecks, Plus, Search } from 'lucide-react';
import PageHeader from '@/components/common/PageHeader';
import EmptyState from '@/components/common/EmptyState';
import TaskDialog from '@/components/tasks/TaskDialog';
import KanbanColumn from '@/components/tasks/KanbanColumn';
import { useCollection } from '@/hooks/useCollection';
import { base44 } from '@/api/base44Client';

const COLUMNS = [
  { key: 'todo', label: 'To do', dot: 'bg-border' },
  { key: 'in_progress', label: 'In progress', dot: 'bg-chart-1' },
  { key: 'review', label: 'Review', dot: 'bg-chart-5' },
  { key: 'done', label: 'Done', dot: 'bg-chart-4' },
];

export default function Tasks() {
  const tasks = useCollection('Task', {}, { sort: 'due_date' });
  const projects = useCollection('Project', {}, { sort: 'name' });
  const [projectId, setProjectId] = useState('');
  const [query, setQuery] = useState('');
  const [open, setOpen] = useState(false);
  const [editing, setEditing] = useState(null);
  const draggedAt = useRef(0);

  const visible = useMemo(() => {
    const q = query.trim().toLowerCase();
    return tasks.items.filter((t) => {
      if (projectId && t.project_id !== projectId) return false;
      if (q && !`${t.title} ${t.assignee || ''} ${t.project_name || ''}`.toLowerCase().includes(q)) return false;
      return true;
    });
  }, [tasks.items, projectId, query]);

  const activeProject = projects.items.find((p) => p.id === projectId) || null;
  const today = new Date(new Date().toDateString());
  const doneCount = tasks.items.filter((t) => t.status === 'done').length;
  const overdue = tasks.items.filter((t) => t.status !== 'done' && t.due_date && new Date(t.due_date) < today).length;

  const openTask = (task) => {
    // A drag ends with a click on the card — don't open the editor for it.
    if (Date.now() - draggedAt.current < 250) return;
    setEditing(task);
    setOpen(true);
  };

  const onDragEnd = async (result) => {
    draggedAt.current = Date.now();
    const { destination, source, draggableId } = result;
    if (!destination) return;
    if (destination.droppableId === source.droppableId) return;
    const task = tasks.items.find((t) => t.id === draggableId);
    if (!task) return;

    const nextStatus = destination.droppableId;
    tasks.setItems((prev) => prev.map((t) => (t.id === draggableId ? { ...t, status: nextStatus } : t)));
    try {
      await base44.entities.Task.update(draggableId, { status: nextStatus });
    } catch {
      tasks.setItems((prev) => prev.map((t) => (t.id === draggableId ? { ...t, status: task.status } : t)));
    }
  };

  const quickAdd = async (title, status) => {
    await base44.entities.Task.create({
      title,
      status,
      priority: 'medium',
      project_id: activeProject?.id || '',
      project_name: activeProject?.name || '',
      sample: false,
    });
    await tasks.reload();
  };

  return (
    <div>
      <PageHeader
        eyebrow="Delivery"
        title="Task board"
        description={`${tasks.items.length - doneCount} open · ${doneCount} done · ${overdue} overdue`}
        actions={
          <button
            className="btn-ink"
            onClick={() => {
              setEditing(null);
              setOpen(true);
            }}
          >
            <Plus className="h-4 w-4" /> New task
          </button>
        }
      />

      <div className="mb-5 flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
        <div className="flex flex-wrap items-center gap-2">
          <select value={projectId} onChange={(e) => setProjectId(e.target.value)} className="field w-auto py-2">
            <option value="">All projects</option>
            {projects.items.map((p) => (
              <option key={p.id} value={p.id}>
                {p.name}
              </option>
            ))}
          </select>
          <div className="relative">
            <Search className="pointer-events-none absolute left-3 top-1/2 h-3.5 w-3.5 -translate-y-1/2 text-muted-foreground" />
            <input
              value={query}
              onChange={(e) => setQuery(e.target.value)}
              placeholder="Search tasks or people…"
              className="field w-full py-2 pl-8 sm:w-60"
            />
          </div>
        </div>
        <p className="text-[11.5px] text-muted-foreground">
          Drag a card to another column to move it — changes save instantly.
        </p>
      </div>

      {tasks.loading ? (
        <div className="grid grid-cols-1 gap-3 md:grid-cols-2 xl:grid-cols-4">
          {COLUMNS.map((c) => (
            <div key={c.key} className="h-60 animate-pulse rounded-2xl border border-border bg-card/60" />
          ))}
        </div>
      ) : tasks.items.length === 0 ? (
        <EmptyState
          icon={ListChecks}
          title="No tasks yet"
          description="Add your first task, then drag it from To do to Done as the work moves forward."
          action={
            <button
              className="btn-ink"
              onClick={() => {
                setEditing(null);
                setOpen(true);
              }}
            >
              <Plus className="h-4 w-4" /> New task
            </button>
          }
        />
      ) : (
        <DragDropContext onDragEnd={onDragEnd}>
          <div className="grid grid-cols-1 gap-3 md:grid-cols-2 xl:grid-cols-4">
            {COLUMNS.map((column, i) => (
              <motion.div
                key={column.key}
                initial={{ opacity: 0, y: 14 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.4, delay: i * 0.06, ease: [0.22, 1, 0.36, 1] }}
              >
                <KanbanColumn
                  column={column}
                  tasks={visible.filter((t) => t.status === column.key)}
                  onOpen={openTask}
                  onQuickAdd={quickAdd}
                />
              </motion.div>
            ))}
          </div>
        </DragDropContext>
      )}

      <TaskDialog
        open={open}
        task={editing}
        project={editing ? null : activeProject}
        projects={projects.items}
        onClose={() => setOpen(false)}
        onSaved={tasks.reload}
      />
    </div>
  );
}
