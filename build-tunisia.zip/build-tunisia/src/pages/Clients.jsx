import { useMemo, useState } from 'react';
import { Link } from 'react-router-dom';
import { Plus, Search, Users } from 'lucide-react';
import PageHeader from '@/components/common/PageHeader';
import EmptyState from '@/components/common/EmptyState';
import ClientDialog from '@/components/clients/ClientDialog';
import { useCollection } from '@/hooks/useCollection';
import { useWorkspace } from '@/lib/workspace';
import { initials, money, shortDate } from '@/lib/format';

const categories = [
  { value: 'all', label: 'All' },
  { value: 'lead', label: 'Leads' },
  { value: 'active', label: 'Active' },
  { value: 'vip', label: 'VIP' },
  { value: 'inactive', label: 'Inactive' },
];

const catStyle = {
  lead: 'bg-chart-4/15 text-chart-4',
  active: 'bg-accent/30 text-foreground',
  vip: 'bg-primary text-primary-foreground',
  inactive: 'bg-secondary text-muted-foreground',
};

export default function Clients() {
  const { currency } = useWorkspace();
  const { items, loading, reload } = useCollection('Client', {}, { sort: 'name' });
  const [query, setQuery] = useState('');
  const [category, setCategory] = useState('all');
  const [dialog, setDialog] = useState({ open: false, client: null });

  const filtered = useMemo(() => {
    const q = query.trim().toLowerCase();
    return items.filter((c) => {
      const matchesCat = category === 'all' || c.category === category;
      const matchesQuery =
        !q ||
        [c.name, c.company, c.email].filter(Boolean).some((v) => String(v).toLowerCase().includes(q));
      return matchesCat && matchesQuery;
    });
  }, [items, query, category]);

  const totalPipeline = items.reduce((s, c) => s + (Number(c.value_estimate) || 0), 0);

  return (
    <div>
      <PageHeader
        eyebrow="CRM"
        title="Customers"
        description={`${items.length} records · ${money(totalPipeline, currency, true)} in tracked value`}
        actions={
          <button className="btn-ink" onClick={() => setDialog({ open: true, client: null })}>
            <Plus className="h-4 w-4" /> New client
          </button>
        }
      />

      <div className="mb-6 flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
        <div className="relative w-full sm:max-w-xs">
          <Search className="pointer-events-none absolute left-3.5 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
          <input
            className="field pl-10"
            placeholder="Search name, company, email"
            value={query}
            onChange={(e) => setQuery(e.target.value)}
          />
        </div>
        <div className="flex flex-wrap gap-1.5">
          {categories.map((c) => (
            <button
              key={c.value}
              onClick={() => setCategory(c.value)}
              className={`rounded-full px-3 py-1.5 text-[12px] font-medium transition-all ${
                category === c.value
                  ? 'bg-primary text-primary-foreground'
                  : 'border border-border bg-card text-muted-foreground hover:text-foreground'
              }`}
            >
              {c.label}
            </button>
          ))}
        </div>
      </div>

      {loading ? (
        <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 xl:grid-cols-3">
          {[0, 1, 2, 3, 4, 5].map((i) => (
            <div key={i} className="h-36 animate-pulse rounded-2xl border border-border bg-card/60" />
          ))}
        </div>
      ) : filtered.length === 0 ? (
        <EmptyState
          icon={Users}
          title={items.length ? 'No clients match this filter' : 'No customers yet'}
          description={
            items.length
              ? 'Try another category or clear your search.'
              : 'Add your first customer record to start tracking history, projects and invoices.'
          }
          action={
            <button className="btn-ink" onClick={() => setDialog({ open: true, client: null })}>
              <Plus className="h-4 w-4" /> New client
            </button>
          }
        />
      ) : (
        <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 xl:grid-cols-3">
          {filtered.map((c) => (
            <Link
              key={c.id}
              to={`/clients/${c.id}`}
              className="surface group p-5 transition-all duration-300 hover:-translate-y-0.5 hover:shadow-[0_1px_2px_rgba(20,21,15,0.05),0_24px_48px_-32px_rgba(20,21,15,0.5)]"
            >
              <div className="flex items-start justify-between">
                <div className="flex h-10 w-10 items-center justify-center rounded-full bg-secondary text-[12px] font-semibold">
                  {initials(c.name)}
                </div>
                <span
                  className={`rounded-full px-2.5 py-1 text-[10.5px] font-medium capitalize ${
                    catStyle[c.category] || catStyle.lead
                  }`}
                >
                  {c.category}
                </span>
              </div>
              <p className="mt-3.5 text-[14.5px] font-medium group-hover:underline">{c.name}</p>
              <p className="text-[12px] text-muted-foreground">{c.company || c.email || '—'}</p>
              <div className="mt-4 flex items-end justify-between border-t border-border pt-3">
                <div>
                  <p className="text-[10px] uppercase tracking-[0.12em] text-muted-foreground">Value</p>
                  <p className="num text-[17px]">{money(c.value_estimate, currency, true)}</p>
                </div>
                <p className="text-[11px] text-muted-foreground">
                  Last contact {c.last_contact ? shortDate(c.last_contact) : '—'}
                </p>
              </div>
            </Link>
          ))}
        </div>
      )}

      <ClientDialog
        open={dialog.open}
        client={dialog.client}
        onClose={() => setDialog({ open: false, client: null })}
        onSaved={reload}
      />
    </div>
  );
}
