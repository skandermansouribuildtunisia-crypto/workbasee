import { useEffect, useState } from 'react';
import { Link, useNavigate, useParams } from 'react-router-dom';
import { ArrowLeft, Mail, Phone, Pencil, Plus, Share2, Trash2, Users } from 'lucide-react';
import { base44 } from '@/api/base44Client';
import PageHeader from '@/components/common/PageHeader';
import StatTile from '@/components/common/StatTile';
import ClientDialog from '@/components/clients/ClientDialog';
import { useCollection } from '@/hooks/useCollection';
import { useWorkspace } from '@/lib/workspace';
import { longDate, money, shortDate } from '@/lib/format';

export default function ClientDetail() {
  const { id } = useParams();
  const navigate = useNavigate();
  const { currency } = useWorkspace();
  const [client, setClient] = useState(null);
  const [editOpen, setEditOpen] = useState(false);
  const [note, setNote] = useState({ type: 'note', summary: '' });
  const [saving, setSaving] = useState(false);
  const [copied, setCopied] = useState(false);

  const interactions = useCollection('Interaction', { client_id: id }, { sort: '-date' });
  const projects = useCollection('Project', { client_id: id });
  const invoices = useCollection('Invoice', { client_id: id }, { sort: '-issue_date' });

  const load = async () => {
    const data = await base44.entities.Client.get(id).catch(() => null);
    setClient(data);
  };

  useEffect(() => {
    load();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [id]);

  const addNote = async () => {
    if (!note.summary.trim()) return;
    setSaving(true);
    await base44.entities.Interaction.create({
      client_id: id,
      client_name: client?.company || client?.name || '',
      type: note.type,
      summary: note.summary.trim(),
      date: new Date().toISOString().slice(0, 10),
    });
    await base44.entities.Client.update(id, { last_contact: new Date().toISOString().slice(0, 10) });
    setNote({ type: 'note', summary: '' });
    setSaving(false);
    interactions.reload();
    load();
  };

  const remove = async () => {
    await base44.entities.Client.delete(id);
    navigate('/clients');
  };

  const copyPortal = async () => {
    let token = client.portal_token;
    if (!token) {
      token = crypto.randomUUID().replace(/-/g, '');
      await base44.entities.Client.update(id, { portal_token: token });
      await load();
    }
    await navigator.clipboard.writeText(`${window.location.origin}/portal/${token}`);
    setCopied(true);
    setTimeout(() => setCopied(false), 2400);
  };

  if (!client) {
    return <div className="h-64 animate-pulse rounded-2xl border border-border bg-card/60" />;
  }

  const paid = invoices.items.filter((i) => i.status === 'paid').reduce((s, i) => s + (Number(i.total) || 0), 0);
  const open = invoices.items.filter((i) => i.status !== 'paid').reduce((s, i) => s + (Number(i.total) || 0), 0);

  return (
    <div>
      <Link to="/clients" className="mb-6 inline-flex items-center gap-1.5 text-[12.5px] text-muted-foreground hover:text-foreground">
        <ArrowLeft className="h-3.5 w-3.5" /> All customers
      </Link>

      <PageHeader
        eyebrow={client.category?.toUpperCase()}
        title={client.company || client.name}
        description={client.company ? `Contact — ${client.name}` : 'Customer record'}
        actions={
          <>
            <button className="btn-ghost" onClick={copyPortal}>
              <Share2 className="h-4 w-4" /> {copied ? 'Link copied' : 'Portal link'}
            </button>
            <button className="btn-ghost" onClick={() => setEditOpen(true)}>
              <Pencil className="h-4 w-4" /> Edit
            </button>
            <button className="btn-ink" onClick={remove}>
              <Trash2 className="h-4 w-4" /> Delete
            </button>
          </>
        }
      />

      <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 xl:grid-cols-4">
        <StatTile label="Paid to date" value={money(paid, currency, true)} hint={`${invoices.items.length} invoices`} />
        <StatTile label="Outstanding" value={money(open, currency, true)} hint="Unpaid balance" />
        <StatTile label="Estimated value" value={money(client.value_estimate, currency, true)} hint="Pipeline value" />
        <StatTile label="Projects" value={String(projects.items.length)} hint="All time" />
      </div>

      <div className="mt-6 grid grid-cols-1 gap-6 xl:grid-cols-3">
        <div className="xl:col-span-2 space-y-6">
          <div className="surface p-5 sm:p-6">
            <div className="mb-4 flex items-center justify-between">
              <h2 className="text-[17px] tracking-[-0.01em]">Communication history</h2>
              <span className="text-[11.5px] text-muted-foreground">{interactions.items.length} entries</span>
            </div>

            <div className="mb-6 rounded-xl border border-border bg-secondary/40 p-3">
              <div className="flex flex-col gap-2 sm:flex-row">
                <select
                  className="field sm:w-32"
                  value={note.type}
                  onChange={(e) => setNote({ ...note, type: e.target.value })}
                >
                  <option value="note">Note</option>
                  <option value="call">Call</option>
                  <option value="email">Email</option>
                  <option value="meeting">Meeting</option>
                </select>
                <input
                  className="field flex-1"
                  placeholder="Log what was discussed…"
                  value={note.summary}
                  onChange={(e) => setNote({ ...note, summary: e.target.value })}
                  onKeyDown={(e) => e.key === 'Enter' && addNote()}
                />
                <button className="btn-lime" onClick={addNote} disabled={saving || !note.summary.trim()}>
                  <Plus className="h-4 w-4" /> Log
                </button>
              </div>
            </div>

            <div className="space-y-4">
              {interactions.items.map((it) => (
                <div key={it.id} className="flex gap-3">
                  <div className="mt-1.5 h-2 w-2 shrink-0 rounded-full bg-accent" />
                  <div className="min-w-0 flex-1 border-b border-border pb-3">
                    <div className="flex items-center gap-2 text-[11px] uppercase tracking-[0.1em] text-muted-foreground">
                      <span>{it.type}</span>·<span>{shortDate(it.date)}</span>
                    </div>
                    <p className="mt-1 text-[13px] leading-relaxed">{it.summary}</p>
                  </div>
                </div>
              ))}
              {interactions.items.length === 0 && (
                <p className="py-6 text-center text-[12.5px] text-muted-foreground">
                  No conversations logged yet.
                </p>
              )}
            </div>
          </div>

          <div className="surface p-5 sm:p-6">
            <h2 className="mb-4 text-[17px] tracking-[-0.01em]">Projects</h2>
            <div className="divide-y divide-border">
              {projects.items.map((p) => (
                <Link key={p.id} to={`/projects/${p.id}`} className="row-hover flex items-center justify-between rounded-lg px-2 py-3">
                  <div>
                    <p className="text-[13.5px] font-medium">{p.name}</p>
                    <p className="text-[11.5px] capitalize text-muted-foreground">
                      {p.status.replace('_', ' ')} · due {shortDate(p.due_date)}
                    </p>
                  </div>
                  <span className="num text-[15px]">{money(p.budget, currency, true)}</span>
                </Link>
              ))}
              {projects.items.length === 0 && (
                <p className="py-4 text-[12.5px] text-muted-foreground">No projects for this customer yet.</p>
              )}
            </div>
          </div>
        </div>

        <div className="space-y-6">
          <div className="surface p-5">
            <h2 className="mb-4 text-[17px] tracking-[-0.01em]">Contact</h2>
            <div className="space-y-3 text-[12.5px]">
              <p className="flex items-center gap-2">
                <Mail className="h-3.5 w-3.5 text-muted-foreground" /> {client.email || '—'}
              </p>
              <p className="flex items-center gap-2">
                <Phone className="h-3.5 w-3.5 text-muted-foreground" /> {client.phone || '—'}
              </p>
              <p className="flex items-center gap-2">
                <Users className="h-3.5 w-3.5 text-muted-foreground" /> Source — {client.source || '—'}
              </p>
              <p className="text-muted-foreground">Last contact — {longDate(client.last_contact)}</p>
            </div>
            {client.notes && (
              <p className="mt-4 rounded-xl bg-secondary/60 p-3 text-[12.5px] leading-relaxed text-muted-foreground">
                {client.notes}
              </p>
            )}
          </div>

          <div className="surface p-5">
            <h2 className="mb-4 text-[17px] tracking-[-0.01em]">Invoices</h2>
            <div className="divide-y divide-border">
              {invoices.items.map((inv) => (
                <Link key={inv.id} to={`/invoices/${inv.id}`} className="row-hover flex items-center justify-between rounded-lg px-2 py-2.5">
                  <div>
                    <p className="text-[12.5px] font-medium">{inv.number}</p>
                    <p className="text-[11px] capitalize text-muted-foreground">{inv.status}</p>
                  </div>
                  <span className="num text-[14px]">{money(inv.total, currency)}</span>
                </Link>
              ))}
              {invoices.items.length === 0 && (
                <p className="py-3 text-[12.5px] text-muted-foreground">No invoices yet.</p>
              )}
            </div>
          </div>
        </div>
      </div>

      <ClientDialog open={editOpen} client={client} onClose={() => setEditOpen(false)} onSaved={load} />
    </div>
  );
}
