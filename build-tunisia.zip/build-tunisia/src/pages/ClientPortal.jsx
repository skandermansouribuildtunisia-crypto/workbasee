import { useEffect, useState } from 'react';
import { Link, useParams } from 'react-router-dom';
import { CalendarClock, Loader2 } from 'lucide-react';
import { base44 } from '@/api/base44Client';
import { longDate, money } from '@/lib/format';

const STATUS_STYLES = {
  paid: 'bg-accent/35 text-foreground',
  sent: 'bg-chart-1/25 text-foreground',
  overdue: 'bg-destructive/15 text-destructive',
  draft: 'bg-secondary text-muted-foreground',
};

export default function ClientPortal() {
  const { token } = useParams();
  const [data, setData] = useState(null);
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    base44.functions
      .invoke('clientPortal', { token })
      .then((res) => setData(res.data))
      .catch((err) => setError(err?.response?.data?.error || 'This portal link is not valid.'))
      .finally(() => setLoading(false));
  }, [token]);

  useEffect(() => {
    if (loading || !error) return;
    const meta = document.createElement('meta');
    meta.name = 'prerender-status-code';
    meta.content = '404';
    document.head.appendChild(meta);
    return () => {
      document.head.removeChild(meta);
    };
  }, [loading, error]);

  return (
    <div className="min-h-screen bg-background px-5 py-12">
      <div className="mx-auto w-full max-w-3xl">
        <div className="mb-7 flex items-center gap-2">
          <span className="h-2.5 w-2.5 rounded-full bg-accent" />
          <span className="text-[12px] font-semibold uppercase tracking-[0.2em]">Client portal</span>
        </div>

        {loading ? (
          <div className="flex items-center gap-2 py-16 text-[13px] text-muted-foreground">
            <Loader2 className="h-4 w-4 animate-spin" /> Loading your workspace…
          </div>
        ) : error ? (
          <div className="surface p-8">
            <h1 className="text-[22px] tracking-[-0.01em]">This link does not work</h1>
            <p className="mt-2 text-[12.5px] text-muted-foreground">
              {error} Ask your contact for a fresh portal link.
            </p>
          </div>
        ) : (
          <>
            <h1 className="text-[30px] leading-[1.1] tracking-[-0.02em] sm:text-[36px]">{data.client.name}</h1>
            <p className="mt-2 text-[13px] text-muted-foreground">
              Your projects and invoices in one place{data.client.contact ? ` · ${data.client.contact}` : ''}
            </p>

            <div className="surface mt-7 p-5">
              <h2 className="mb-3 text-[15px] tracking-[-0.01em]">Projects</h2>
              {data.projects.length === 0 ? (
                <p className="text-[12.5px] text-muted-foreground">No projects on file yet.</p>
              ) : (
                <div className="divide-y divide-border">
                  {data.projects.map((project) => (
                    <div key={project.name} className="py-3">
                      <div className="flex flex-wrap items-center justify-between gap-2">
                        <p className="text-[13px] font-medium">{project.name}</p>
                        <span className="rounded-full bg-secondary px-2 py-0.5 text-[10px] capitalize text-muted-foreground">
                          {String(project.status).replace('_', ' ')}
                        </span>
                      </div>
                      {project.objective && (
                        <p className="mt-1 text-[11.5px] leading-relaxed text-muted-foreground">{project.objective}</p>
                      )}
                      <p className="mt-1 text-[11px] text-muted-foreground">
                        {project.start_date ? `Started ${longDate(project.start_date)}` : 'Not started'}
                        {project.due_date ? ` · Due ${longDate(project.due_date)}` : ''}
                      </p>
                    </div>
                  ))}
                </div>
              )}
            </div>

            <div className="surface mt-5 p-5">
              <h2 className="mb-3 text-[15px] tracking-[-0.01em]">Invoices</h2>
              {data.invoices.length === 0 ? (
                <p className="text-[12.5px] text-muted-foreground">No invoices issued yet.</p>
              ) : (
                <div className="divide-y divide-border">
                  {data.invoices.map((invoice) => (
                    <div key={invoice.number} className="flex flex-wrap items-center justify-between gap-2 py-3">
                      <div>
                        <p className="num text-[12.5px]">{invoice.number}</p>
                        <p className="text-[11px] text-muted-foreground">Due {longDate(invoice.due_date)}</p>
                      </div>
                      <div className="flex items-center gap-3">
                        <span className={`rounded-full px-2 py-0.5 text-[10px] capitalize ${STATUS_STYLES[invoice.status] || STATUS_STYLES.draft}`}>
                          {invoice.status}
                        </span>
                        <span className="num text-[14px]">{money(invoice.total, invoice.currency)}</span>
                        {invoice.pay_token && (
                          <Link to={`/pay/${invoice.pay_token}`} className="btn-ink py-1.5 text-[11.5px]">
                            Pay
                          </Link>
                        )}
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>

            <Link to="/book" className="btn-ghost mt-5 w-full justify-center py-2.5">
              <CalendarClock className="h-4 w-4" /> Book a call
            </Link>
          </>
        )}

        <p className="mt-10 text-center text-[11px] text-muted-foreground">Powered by workbase</p>
      </div>
    </div>
  );
}
