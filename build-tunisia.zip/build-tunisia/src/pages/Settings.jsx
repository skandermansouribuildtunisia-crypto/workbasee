import { useEffect, useState } from 'react';
import { LogOut } from 'lucide-react';
import { base44 } from '@/api/base44Client';
import PageHeader from '@/components/common/PageHeader';
import { FormGrid, SelectField, TextField } from '@/components/common/Field';
import { useWorkspace } from '@/lib/workspace';
import DataImport from '@/components/settings/DataImport';

const plans = [
  { name: 'Starter', price: '$0', detail: '1 workspace · basic dashboard · customers · limited invoices' },
  { name: 'Pro', price: '$19', detail: 'Advanced CRM · finance · unlimited projects · AI assistant' },
  { name: 'Business', price: '$49', detail: 'Team, inventory, advanced automation and website' },
  { name: 'Enterprise', price: '$99', detail: 'Multiple workspaces, permissions, priority support' },
];

export default function Settings() {
  const { profile, refresh, company } = useWorkspace();
  const [form, setForm] = useState({ company_name: '', industry: '', currency: 'USD' });
  const [saved, setSaved] = useState(false);
  const [busy, setBusy] = useState(false);

  useEffect(() => {
    if (!profile) return;
    setForm({
      company_name: profile.company_name || '',
      industry: profile.industry || '',
      currency: profile.currency || 'USD',
    });
  }, [profile]);

  const save = async () => {
    setBusy(true);
    await base44.auth.updateMe(form);
    await refresh();
    setBusy(false);
    setSaved(true);
    setTimeout(() => setSaved(false), 2200);
  };

  return (
    <div>
      <PageHeader
        eyebrow="Workspace"
        title="Settings"
        description="How your business appears across the workspace, and what it is charged in."
      />

      <div className="grid grid-cols-1 gap-6 xl:grid-cols-3">
        <div className="surface p-5 sm:p-6 xl:col-span-2">
          <h2 className="mb-4 text-[17px] tracking-[-0.01em]">Business profile</h2>
          <div className="space-y-4">
            <FormGrid>
              <TextField
                label="Business name"
                value={form.company_name}
                onChange={(v) => setForm({ ...form, company_name: v })}
                placeholder={company}
              />
              <TextField
                label="Industry"
                value={form.industry}
                onChange={(v) => setForm({ ...form, industry: v })}
                placeholder="Design studio, construction, retail…"
              />
              <SelectField
                label="Currency"
                value={form.currency}
                onChange={(v) => setForm({ ...form, currency: v })}
                options={[
                  { value: 'USD', label: 'USD — US Dollar' },
                  { value: 'EUR', label: 'EUR — Euro' },
                  { value: 'GBP', label: 'GBP — Pound' },
                  { value: 'TND', label: 'TND — Dinar' },
                ]}
              />
              <div>
                <p className="mb-1.5 text-[11.5px] font-medium uppercase tracking-[0.1em] text-muted-foreground">
                  Signed in as
                </p>
                <p className="field truncate text-muted-foreground">{profile?.email || '—'}</p>
              </div>
            </FormGrid>
            <div className="flex items-center gap-3 pt-2">
              <button className="btn-ink" onClick={save} disabled={busy}>
                {busy ? 'Saving…' : 'Save profile'}
              </button>
              {saved && <span className="text-[12px] text-muted-foreground">Saved</span>}
            </div>
          </div>
        </div>

        <div className="space-y-6">
          <div className="surface p-5">
            <h2 className="mb-3 text-[17px] tracking-[-0.01em]">Plan</h2>
            <div className="flex items-baseline gap-2">
              <span className="num text-[30px] leading-none">Starter</span>
              <span className="text-[12px] text-muted-foreground">current plan</span>
            </div>
            <p className="mt-3 text-[12px] leading-relaxed text-muted-foreground">
              One workspace, customers, projects, invoices and expenses. Upgrade when you need the team, inventory
              and automation layers.
            </p>
            <div className="mt-4 space-y-2 border-t border-border pt-3">
              {plans.slice(1).map((p) => (
                <div key={p.name} className="flex items-baseline justify-between text-[12px]">
                  <span>{p.name}</span>
                  <span className="text-muted-foreground">
                    {p.price} <span className="text-[10.5px]">/ month</span>
                  </span>
                </div>
              ))}
            </div>
            <p className="mt-4 text-[11px] leading-relaxed text-muted-foreground">
              Billing is not connected in this build — no card is ever charged.
            </p>
          </div>

          <DataImport />

          <button
            onClick={() => base44.auth.logout('/login')}
            className="flex w-full items-center justify-center gap-2 rounded-2xl border border-border bg-card px-4 py-3 text-[12.5px] font-medium transition hover:bg-secondary"
          >
            <LogOut className="h-4 w-4" /> Sign out
          </button>
        </div>
      </div>
    </div>
  );
}
