import { useState } from 'react';
import { Link } from 'react-router-dom';
import { PackageCheck, ShoppingBag } from 'lucide-react';
import PageHeader from '@/components/common/PageHeader';
import EmptyState from '@/components/common/EmptyState';
import { useCollection } from '@/hooks/useCollection';
import { base44 } from '@/api/base44Client';
import { money, longDate } from '@/lib/format';
import SiteConnection from '@/components/orders/SiteConnection';

const FILTERS = [
  { value: 'all', label: 'All' },
  { value: 'pending', label: 'Awaiting payment' },
  { value: 'paid', label: 'Paid' },
  { value: 'fulfilled', label: 'Fulfilled' },
];

const STATUS_STYLES = {
  pending: 'bg-chart-5/25 text-foreground',
  paid: 'bg-accent/35 text-foreground',
  fulfilled: 'bg-chart-4/15 text-foreground',
  cancelled: 'bg-secondary text-muted-foreground',
};

export default function Orders() {
  const orders = useCollection('StoreOrder', {}, { sort: '-created_date' });
  const [filter, setFilter] = useState('all');
  const [busy, setBusy] = useState('');

  const visible = filter === 'all' ? orders.items : orders.items.filter((o) => o.status === filter);
  const currency = orders.items[0]?.currency || 'USD';
  const revenue = orders.items
    .filter((o) => o.status === 'paid' || o.status === 'fulfilled')
    .reduce((sum, o) => sum + (Number(o.subtotal) || 0), 0);
  const waiting = orders.items.filter((o) => o.status === 'paid').length;

  const fulfil = async (order) => {
    setBusy(order.id);
    try {
      await base44.entities.StoreOrder.update(order.id, {
        status: 'fulfilled',
        fulfilled_at: new Date().toISOString(),
      });
      await orders.reload();
    } finally {
      setBusy('');
    }
  };

  return (
    <div>
      <PageHeader
        eyebrow="Store"
        title="Store orders"
        description={`${money(revenue, currency)} collected · ${waiting} ready to pack`}
        actions={
          <Link to="/shop" className="btn-ghost">
            <ShoppingBag className="h-4 w-4" /> Open storefront
          </Link>
        }
      />

      <SiteConnection />

      <div className="mb-4 flex flex-wrap gap-1.5">
        {FILTERS.map((option) => (
          <button
            key={option.value}
            onClick={() => setFilter(option.value)}
            className={`rounded-full px-3.5 py-1.5 text-[11.5px] transition ${
              filter === option.value
                ? 'bg-primary text-primary-foreground'
                : 'border border-border bg-card text-muted-foreground hover:text-foreground'
            }`}
          >
            {option.label}
          </button>
        ))}
      </div>

      {orders.loading ? (
        <div className="space-y-2">
          {[0, 1, 2].map((i) => (
            <div key={i} className="h-20 animate-pulse rounded-2xl border border-border bg-card/60" />
          ))}
        </div>
      ) : orders.items.length === 0 ? (
        <EmptyState
          icon={ShoppingBag}
          title="No store orders yet"
          description="Publish products in Inventory, share your shop link, and paid orders will appear here."
          action={
            <Link to="/inventory" className="btn-ink">
              Publish products
            </Link>
          }
        />
      ) : (
        <div className="space-y-2.5">
          {visible.map((order) => (
            <div key={order.id} className="surface flex flex-col gap-3 p-4 sm:flex-row sm:items-center sm:justify-between">
              <div className="min-w-0">
                <div className="flex flex-wrap items-center gap-2">
                  <span className="num text-[14px]">{order.number}</span>
                  <span
                    className={`rounded-full px-2 py-0.5 text-[10.5px] font-medium capitalize ${
                      STATUS_STYLES[order.status] || 'bg-secondary'
                    }`}
                  >
                    {order.status}
                  </span>
                </div>
                <p className="mt-1 truncate text-[12.5px]">
                  {order.customer_name || 'Customer'}
                  {order.customer_email ? <span className="text-muted-foreground"> · {order.customer_email}</span> : null}
                </p>
                <p className="mt-0.5 truncate text-[11.5px] text-muted-foreground">
                  {(order.items || []).map((item) => `${item.name} × ${item.qty}`).join(', ') || 'No items'}
                </p>
              </div>

              <div className="flex items-center gap-4 sm:justify-end">
                <div className="text-right">
                  <p className="num text-[16px]">{money(order.subtotal, order.currency || currency)}</p>
                  <p className="text-[11px] text-muted-foreground">{longDate(order.created_date)}</p>
                </div>
                {order.status === 'paid' && (
                  <button
                    onClick={() => fulfil(order)}
                    disabled={busy === order.id}
                    className="btn-ghost whitespace-nowrap py-2 text-[12px]"
                  >
                    <PackageCheck className="h-3.5 w-3.5" />
                    {busy === order.id ? 'Saving…' : 'Mark fulfilled'}
                  </button>
                )}
              </div>
            </div>
          ))}
          {visible.length === 0 && (
            <p className="py-10 text-center text-[12.5px] text-muted-foreground">No orders in this stage.</p>
          )}
        </div>
      )}
    </div>
  );
}
