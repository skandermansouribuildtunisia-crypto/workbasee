import { useMemo } from 'react';
import { Link } from 'react-router-dom';
import { BarChart3 } from 'lucide-react';
import PageHeader from '@/components/common/PageHeader';
import StatTile from '@/components/common/StatTile';
import EmptyState from '@/components/common/EmptyState';
import RevenueChart from '@/components/dashboard/RevenueChart';
import { useCollection } from '@/hooks/useCollection';
import { useWorkspace } from '@/lib/workspace';
import { expenseByCategory, monthSeries, projectFinance } from '@/lib/derive';
import { money } from '@/lib/format';

const palette = ['hsl(var(--chart-1))', 'hsl(var(--chart-2))', 'hsl(var(--chart-3))', 'hsl(var(--chart-4))', 'hsl(var(--chart-5))'];

export default function Reports() {
  const { currency } = useWorkspace();
  const invoices = useCollection('Invoice');
  const expenses = useCollection('Expense');
  const projects = useCollection('Project');
  const clients = useCollection('Client');
  const tasks = useCollection('Task');

  const series = monthSeries(invoices.items, expenses.items, 6);
  const categories = expenseByCategory(expenses.items);
  const totalExpenses = categories.reduce((s, c) => s + c.value, 0);

  const ranked = useMemo(
    () =>
      projects.items
        .map((p) => ({ project: p, ...projectFinance(p, expenses.items, invoices.items, tasks.items) }))
        .sort((a, b) => b.profit - a.profit),
    [projects.items, expenses.items, invoices.items, tasks.items]
  );

  const topClients = useMemo(() => {
    const map = {};
    invoices.items
      .filter((i) => i.status === 'paid')
      .forEach((i) => {
        const key = i.client_name || 'Unknown';
        map[key] = (map[key] || 0) + (Number(i.total) || 0);
      });
    return Object.entries(map)
      .map(([name, value]) => ({ name, value }))
      .sort((a, b) => b.value - a.value)
      .slice(0, 5);
  }, [invoices.items]);

  const paid = invoices.items.filter((i) => i.status === 'paid').reduce((s, i) => s + (Number(i.total) || 0), 0);
  const spend = expenses.items.reduce((s, e) => s + (Number(e.amount) || 0), 0);
  const bestMargin = ranked.filter((r) => r.invoiced > 0)[0];

  const empty = !invoices.loading && invoices.items.length === 0 && expenses.items.length === 0;

  return (
    <div>
      <PageHeader
        eyebrow="Analytics"
        title="Reports"
        description="Revenue, costs and the profit each project actually produces."
      />

      {empty ? (
        <EmptyState
          icon={BarChart3}
          title="No numbers to report yet"
          description="Add invoices and expenses and this page fills itself in."
          action={
            <Link to="/invoices" className="btn-ink">
              Create an invoice
            </Link>
          }
        />
      ) : (
        <>
          <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 xl:grid-cols-4">
            <StatTile label="Cash collected" value={money(paid, currency, true)} hint="All paid invoices" />
            <StatTile label="Total spend" value={money(spend, currency, true)} hint="All logged expenses" />
            <StatTile
              label="Gross margin"
              value={paid ? `${Math.round(((paid - spend) / paid) * 100)}%` : '—'}
              hint="Collected minus spend"
            />
            <StatTile
              label="Best project"
              value={bestMargin ? bestMargin.project.name : '—'}
              hint={bestMargin ? `${money(bestMargin.profit, currency, true)} profit` : 'No invoiced project'}
            />
          </div>

          <div className="mt-6 grid grid-cols-1 gap-6 xl:grid-cols-3">
            <div className="xl:col-span-2">
              <RevenueChart data={series} currency={currency} />
            </div>

            <div className="surface p-5 sm:p-6">
              <h2 className="mb-1 text-[19px] tracking-[-0.01em]">Where money goes</h2>
              <p className="mb-5 text-[12px] text-muted-foreground">{money(totalExpenses, currency)} logged</p>
              <div className="space-y-3">
                {categories.map((c, i) => {
                  const share = totalExpenses ? Math.round((c.value / totalExpenses) * 100) : 0;
                  return (
                    <div key={c.name}>
                      <div className="mb-1 flex items-center justify-between text-[12px]">
                        <span className="flex items-center gap-2 capitalize">
                          <span
                            className="h-2 w-2 rounded-full"
                            style={{ background: palette[i % palette.length] }}
                          />
                          {c.name}
                        </span>
                        <span className="text-muted-foreground">{share}%</span>
                      </div>
                      <div className="h-1.5 w-full overflow-hidden rounded-full bg-secondary">
                        <div
                          className="h-full rounded-full"
                          style={{ width: `${share}%`, background: palette[i % palette.length] }}
                        />
                      </div>
                    </div>
                  );
                })}
                {categories.length === 0 && (
                  <p className="text-[12.5px] text-muted-foreground">No expenses recorded.</p>
                )}
              </div>
            </div>
          </div>

          <div className="mt-6 grid grid-cols-1 gap-6 xl:grid-cols-3">
            <div className="surface p-5 sm:p-6 xl:col-span-2">
              <h2 className="mb-4 text-[19px] tracking-[-0.01em]">Project profitability</h2>
              <div className="space-y-4">
                {ranked.map((r) => {
                  const max = Math.max(...ranked.map((x) => Math.max(x.invoiced, x.spent)), 1);
                  return (
                    <Link key={r.project.id} to={`/projects/${r.project.id}`} className="block">
                      <div className="mb-1.5 flex items-center justify-between text-[12.5px]">
                        <span className="font-medium">{r.project.name}</span>
                        <span className={r.profit < 0 ? 'text-destructive' : 'text-muted-foreground'}>
                          {money(r.profit, currency, true)} profit
                        </span>
                      </div>
                      <div className="flex gap-1">
                        <div className="h-2 flex-1 overflow-hidden rounded-full bg-secondary">
                          <div className="h-full rounded-full bg-accent" style={{ width: `${(r.paid / max) * 100}%` }} />
                        </div>
                        <div className="h-2 flex-1 overflow-hidden rounded-full bg-secondary">
                          <div className="h-full rounded-full bg-primary/70" style={{ width: `${(r.spent / max) * 100}%` }} />
                        </div>
                      </div>
                    </Link>
                  );
                })}
                {ranked.length === 0 && <p className="text-[12.5px] text-muted-foreground">No projects yet.</p>}
              </div>
              <div className="mt-5 flex items-center gap-4 border-t border-border pt-3 text-[11px] text-muted-foreground">
                <span className="flex items-center gap-1.5">
                  <span className="h-2 w-2 rounded-full bg-accent" /> Paid
                </span>
                <span className="flex items-center gap-1.5">
                  <span className="h-2 w-2 rounded-full bg-primary/70" /> Spent
                </span>
              </div>
            </div>

            <div className="surface p-5 sm:p-6">
              <h2 className="mb-4 text-[19px] tracking-[-0.01em]">Top customers</h2>
              <div className="divide-y divide-border">
                {topClients.map((c, i) => (
                  <div key={c.name} className="flex items-center justify-between py-2.5">
                    <div className="flex items-center gap-2.5">
                      <span className="num text-[13px] text-muted-foreground">{String(i + 1).padStart(2, '0')}</span>
                      <span className="text-[13px]">{c.name}</span>
                    </div>
                    <span className="num text-[14px]">{money(c.value, currency, true)}</span>
                  </div>
                ))}
                {topClients.length === 0 && (
                  <p className="py-3 text-[12.5px] text-muted-foreground">No paid invoices yet.</p>
                )}
              </div>
              <p className="mt-5 border-t border-border pt-3 text-[11px] leading-relaxed text-muted-foreground">
                {clients.items.length} customers · {projects.items.length} projects · {tasks.items.length} tasks tracked
              </p>
            </div>
          </div>
        </>
      )}
    </div>
  );
}
