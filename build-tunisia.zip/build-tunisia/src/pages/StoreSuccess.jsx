import { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { CheckCircle2, Loader2 } from 'lucide-react';
import { base44 } from '@/api/base44Client';
import { money } from '@/lib/format';

export default function StoreSuccess() {
  const sessionId = new URLSearchParams(window.location.search).get('session_id') || '';
  const [order, setOrder] = useState(null);
  const [error, setError] = useState('');
  const [checking, setChecking] = useState(true);

  useEffect(() => {
    localStorage.removeItem('ventureos_cart');
  }, []);

  useEffect(() => {
    if (!sessionId) {
      setError('We could not find this order.');
      setChecking(false);
      return;
    }
    let attempts = 0;
    let timer;
    const check = async () => {
      attempts += 1;
      try {
        const res = await base44.functions.invoke('storeOrderStatus', { session_id: sessionId });
        const found = res.data?.order;
        if (found) setOrder(found);
        if (found && (found.status === 'paid' || found.status === 'fulfilled')) {
          setChecking(false);
          return;
        }
      } catch (err) {
        if (attempts >= 4) {
          setError(err?.response?.data?.error || 'We could not load this order.');
          setChecking(false);
          return;
        }
      }
      if (attempts < 5) timer = setTimeout(check, 2500);
      else setChecking(false);
    };
    check();
    return () => clearTimeout(timer);
  }, [sessionId]);

  const paid = order && (order.status === 'paid' || order.status === 'fulfilled');

  return (
    <div className="min-h-screen bg-background px-5 py-14">
      <div className="mx-auto w-full max-w-xl">
        <div className="surface p-7 sm:p-9">
          {checking && !order ? (
            <div className="flex items-center gap-2 text-[13px] text-muted-foreground">
              <Loader2 className="h-4 w-4 animate-spin" /> Confirming your payment with the bank…
            </div>
          ) : error ? (
            <div className="text-center">
              <h1 className="text-[22px] tracking-[-0.01em]">Order not found</h1>
              <p className="mt-2 text-[12.5px] text-muted-foreground">{error}</p>
            </div>
          ) : (
            <>
              <span className="mb-4 flex h-12 w-12 items-center justify-center rounded-full bg-accent/30">
                <CheckCircle2 className="h-6 w-6" />
              </span>
              <h1 className="text-[26px] leading-tight tracking-[-0.02em]">
                {paid ? 'Thank you — your order is confirmed' : 'Payment is still clearing'}
              </h1>
              <p className="mt-2 text-[12.5px] text-muted-foreground">
                {paid
                  ? 'We have your payment and will be in touch about delivery.'
                  : 'The bank has not confirmed this payment yet. Refresh in a moment to see it here.'}
              </p>

              <div className="mt-6 space-y-2 border-t border-border pt-4 text-[12.5px]">
                <div className="flex justify-between">
                  <span className="text-muted-foreground">Order</span>
                  <span className="num">{order.number}</span>
                </div>
                {(order.items || []).map((item, i) => (
                  <div key={i} className="flex justify-between text-muted-foreground">
                    <span>
                      {item.name} × {item.qty}
                    </span>
                    <span>{money(item.price * item.qty, order.currency)}</span>
                  </div>
                ))}
                <div className="flex items-center justify-between border-t border-border pt-2.5 text-[14px]">
                  <span>Total</span>
                  <span className="num text-[19px]">{money(order.subtotal, order.currency)}</span>
                </div>
              </div>
            </>
          )}

          <Link to="/shop" className="btn-ghost mt-7 w-full justify-center py-2.5">
            Back to the shop
          </Link>
        </div>
      </div>
    </div>
  );
}
