import { useMemo, useState } from 'react';
import { CalendarClock, Check, Link2 } from 'lucide-react';
import PageHeader from '@/components/common/PageHeader';
import EmptyState from '@/components/common/EmptyState';
import BookingRow from '@/components/bookings/BookingRow';
import { useCollection } from '@/hooks/useCollection';
import { base44 } from '@/api/base44Client';

const FILTERS = [
  { value: 'requested', label: 'Requested' },
  { value: 'confirmed', label: 'Confirmed' },
  { value: 'completed', label: 'Done' },
  { value: 'all', label: 'All' },
];

export default function Bookings() {
  const bookings = useCollection('Booking', {}, { sort: 'date' });
  const [filter, setFilter] = useState('requested');
  const [busy, setBusy] = useState('');
  const [copied, setCopied] = useState(false);

  const shareUrl = `${window.location.origin}/book`;

  const sorted = useMemo(
    () =>
      [...bookings.items].sort((a, b) =>
        `${a.date} ${a.time}`.localeCompare(`${b.date} ${b.time}`),
      ),
    [bookings.items],
  );

  const visible = filter === 'all' ? sorted : sorted.filter((booking) => booking.status === filter);
  const requested = bookings.items.filter((booking) => booking.status === 'requested').length;
  const confirmed = bookings.items.filter((booking) => booking.status === 'confirmed').length;

  const setStatus = async (booking, status) => {
    setBusy(booking.id);
    try {
      await base44.entities.Booking.update(booking.id, { status });
      await bookings.reload();
    } finally {
      setBusy('');
    }
  };

  const copyLink = async () => {
    await navigator.clipboard.writeText(shareUrl);
    setCopied(true);
    setTimeout(() => setCopied(false), 2200);
  };

  return (
    <div>
      <PageHeader
        eyebrow="Client portal"
        title="Bookings"
        description={`${requested} waiting for confirmation · ${confirmed} confirmed calls`}
        actions={
          <>
            <a href="/book" target="_blank" rel="noreferrer" className="btn-ghost">
              <CalendarClock className="h-4 w-4" /> Booking page
            </a>
            <button className="btn-ink" onClick={copyLink}>
              {copied ? <Check className="h-4 w-4" /> : <Link2 className="h-4 w-4" />}
              {copied ? 'Link copied' : 'Copy booking link'}
            </button>
          </>
        }
      />

      <div className="mb-4 flex flex-wrap items-center gap-1.5">
        {FILTERS.map((option) => (
          <button
            key={option.value}
            onClick={() => setFilter(option.value)}
            className={`rounded-full px-3.5 py-1.5 text-[11.5px] transition ${
              filter === option.value
                ? 'bg-primary text-primary-foreground'
                : 'border border-border bg-card text-muted-foreground hover:text-foreground'
            }`}
          >
            {option.label}
            {option.value === 'requested' && requested > 0 ? ` · ${requested}` : ''}
          </button>
        ))}
        <span className="ml-auto hidden text-[11px] text-muted-foreground sm:block">
          Share this link with clients: <span className="font-medium text-foreground">/book</span>
        </span>
      </div>

      {bookings.loading ? (
        <div className="space-y-2.5">
          {[0, 1, 2].map((i) => (
            <div key={i} className="h-[86px] animate-pulse rounded-2xl border border-border bg-card/60" />
          ))}
        </div>
      ) : bookings.items.length === 0 ? (
        <EmptyState
          icon={CalendarClock}
          title="No booking requests yet"
          description="Share your booking page and requests land here for you to confirm."
          action={
            <button className="btn-ink" onClick={copyLink}>
              <Link2 className="h-4 w-4" /> Copy booking link
            </button>
          }
        />
      ) : (
        <div className="space-y-2.5">
          {visible.map((booking) => (
            <BookingRow
              key={booking.id}
              booking={booking}
              busy={busy === booking.id}
              onStatus={(status) => setStatus(booking, status)}
            />
          ))}
          {visible.length === 0 && (
            <p className="py-10 text-center text-[12.5px] text-muted-foreground">Nothing in this list.</p>
          )}
        </div>
      )}
    </div>
  );
}
