import { useMemo, useState } from 'react';
import { Package, Plus, Search } from 'lucide-react';
import PageHeader from '@/components/common/PageHeader';
import StatTile from '@/components/common/StatTile';
import EmptyState from '@/components/common/EmptyState';
import ProductDialog, { PRODUCT_CATEGORIES } from '@/components/inventory/ProductDialog';
import StockDialog from '@/components/inventory/StockDialog';
import ProductRow from '@/components/inventory/ProductRow';
import MovementList from '@/components/inventory/MovementList';
import { useCollection } from '@/hooks/useCollection';
import { useWorkspace } from '@/lib/workspace';
import { base44 } from '@/api/base44Client';
import { money } from '@/lib/format';

const qtyOf = (p) => Number(p.quantity) || 0;
const minOf = (p) => Number(p.min_stock) || 0;
const isLow = (p) => qtyOf(p) > 0 && qtyOf(p) <= minOf(p);
const isOut = (p) => qtyOf(p) <= 0;

export default function Inventory() {
  const { currency } = useWorkspace();
  const products = useCollection('Product', {}, { sort: 'name' });
  const suppliers = useCollection('Supplier', {}, { sort: 'name' });
  const movements = useCollection('StockMovement', {}, { sort: '-date', limit: 200 });

  const [tab, setTab] = useState('products');
  const [search, setSearch] = useState('');
  const [category, setCategory] = useState('');
  const [stockFilter, setStockFilter] = useState('');
  const [supplierFilter, setSupplierFilter] = useState('');
  const [dialog, setDialog] = useState({ open: false, product: null });
  const [stockTarget, setStockTarget] = useState(null);

  const filtered = useMemo(() => {
    const q = search.trim().toLowerCase();
    return products.items.filter((p) => {
      if (q) {
        const haystack = `${p.name} ${p.sku || ''} ${p.barcode || ''} ${p.supplier_name || ''}`.toLowerCase();
        if (!haystack.includes(q)) return false;
      }
      if (category && p.category !== category) return false;
      if (supplierFilter && p.supplier_id !== supplierFilter) return false;
      if (stockFilter === 'low' && !isLow(p)) return false;
      if (stockFilter === 'out' && !isOut(p)) return false;
      if (stockFilter === 'ok' && (isLow(p) || isOut(p))) return false;
      return true;
    });
  }, [products.items, search, category, supplierFilter, stockFilter]);

  const stats = useMemo(() => {
    let value = 0;
    let low = 0;
    let out = 0;
    products.items.forEach((p) => {
      value += qtyOf(p) * (Number(p.purchase_price) || 0);
      if (isOut(p)) out += 1;
      else if (isLow(p)) low += 1;
    });
    return { value, low, out };
  }, [products.items]);

  const remove = async (product) => {
    if (!window.confirm(`Delete “${product.name}”? Recorded stock movements stay in the history.`)) return;
    await base44.entities.Product.delete(product.id);
    products.reload();
  };

  return (
    <div>
      <PageHeader
        eyebrow="Operations"
        title="Inventory"
        description={`${products.items.length} products · ${stats.low + stats.out} need attention`}
        actions={
          <button className="btn-ink" onClick={() => setDialog({ open: true, product: null })}>
            <Plus className="h-4 w-4" /> New product
          </button>
        }
      />

      <div className="mb-6 grid grid-cols-2 gap-3 lg:grid-cols-4">
        <StatTile label="Products" value={products.items.length} hint="Tracked in your catalogue" />
        <StatTile label="Stock value" value={money(stats.value, currency)} hint="At purchase cost" />
        <StatTile label="Low stock" value={stats.low} hint="At or below minimum" tone={stats.low ? 'negative' : 'default'} />
        <StatTile label="Out of stock" value={stats.out} hint="Nothing available" tone={stats.out ? 'negative' : 'default'} />
      </div>

      <div className="mb-4 flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
        <div className="flex rounded-full border border-border bg-card p-1">
          {[
            { key: 'products', label: 'Products' },
            { key: 'movements', label: `Movements (${movements.items.length})` },
          ].map((t) => (
            <button
              key={t.key}
              onClick={() => setTab(t.key)}
              className={`rounded-full px-3.5 py-1.5 text-[12.5px] transition ${
                tab === t.key ? 'bg-primary text-primary-foreground' : 'text-muted-foreground hover:text-foreground'
              }`}
            >
              {t.label}
            </button>
          ))}
        </div>

        {tab === 'products' && (
          <div className="flex flex-wrap items-center gap-2">
            <div className="relative">
              <Search className="pointer-events-none absolute left-3 top-1/2 h-3.5 w-3.5 -translate-y-1/2 text-muted-foreground" />
              <input
                value={search}
                onChange={(e) => setSearch(e.target.value)}
                placeholder="Search name, SKU, barcode…"
                className="field w-full pl-8 sm:w-60"
              />
            </div>
            <select value={category} onChange={(e) => setCategory(e.target.value)} className="field w-auto py-2">
              <option value="">All categories</option>
              {PRODUCT_CATEGORIES.map((c) => (
                <option key={c.value} value={c.value}>
                  {c.label}
                </option>
              ))}
            </select>
            <select value={stockFilter} onChange={(e) => setStockFilter(e.target.value)} className="field w-auto py-2">
              <option value="">Any stock level</option>
              <option value="ok">Healthy stock</option>
              <option value="low">Low stock</option>
              <option value="out">Out of stock</option>
            </select>
            <select value={supplierFilter} onChange={(e) => setSupplierFilter(e.target.value)} className="field w-auto py-2">
              <option value="">All suppliers</option>
              {suppliers.items.map((s) => (
                <option key={s.id} value={s.id}>
                  {s.name}
                </option>
              ))}
            </select>
          </div>
        )}
      </div>

      {tab === 'products' ? (
        products.loading ? (
          <div className="h-64 animate-pulse rounded-2xl border border-border bg-card/60" />
        ) : products.items.length === 0 ? (
          <EmptyState
            icon={Package}
            title="No products yet"
            description="Add what you sell or stock, set a minimum level, and workbase tracks the value and warns you before you run out."
            action={
              <button className="btn-ink" onClick={() => setDialog({ open: true, product: null })}>
                <Plus className="h-4 w-4" /> New product
              </button>
            }
          />
        ) : (
          <div className="surface overflow-hidden">
            <div className="hidden grid-cols-[1.7fr_1fr_0.8fr_1fr_auto] gap-3 border-b border-border px-4 py-2.5 text-[10.5px] uppercase tracking-[0.12em] text-muted-foreground md:grid">
              <span>Product</span>
              <span>Supplier</span>
              <span>Stock</span>
              <span>Price</span>
              <span className="text-right">Actions</span>
            </div>
            <div className="divide-y divide-border">
              {filtered.map((p) => (
                <ProductRow
                  key={p.id}
                  product={p}
                  currency={currency}
                  onEdit={(product) => setDialog({ open: true, product })}
                  onAdjust={setStockTarget}
                  onDelete={remove}
                />
              ))}
              {filtered.length === 0 && (
                <p className="px-4 py-10 text-center text-[12.5px] text-muted-foreground">
                  No products match these filters.
                </p>
              )}
            </div>
          </div>
        )
      ) : (
        <MovementList movements={movements.items} currency={currency} />
      )}

      <ProductDialog
        open={dialog.open}
        product={dialog.product}
        suppliers={suppliers.items}
        onClose={() => setDialog({ open: false, product: null })}
        onSaved={() => {
          products.reload();
          movements.reload();
        }}
      />

      <StockDialog
        open={Boolean(stockTarget)}
        product={stockTarget}
        onClose={() => setStockTarget(null)}
        onSaved={() => {
          products.reload();
          movements.reload();
        }}
      />
    </div>
  );
}
