import { Link } from 'react-router-dom';
import { Download, Plus, Sparkles } from 'lucide-react';
import PageHeader from '@/components/common/PageHeader';
import KpiRow from '@/components/dashboard/KpiRow';
import RevenueChart from '@/components/dashboard/RevenueChart';
import AttentionPanel from '@/components/dashboard/AttentionPanel';
import ProjectHealth from '@/components/dashboard/ProjectHealth';
import ActionQueue from '@/components/dashboard/ActionQueue';
import RecentInvoices from '@/components/dashboard/RecentInvoices';
import { useCollection } from '@/hooks/useCollection';
import { useWorkspace } from '@/lib/workspace';
import { buildActions, buildAlerts, delta, isOverdue, monthSeries, projectFinance } from '@/lib/derive';
import { money } from '@/lib/format';

export default function Dashboard() {
  const { currency, userName } = useWorkspace();
  const clients = useCollection('Client');
  const projects = useCollection('Project');
  const tasks = useCollection('Task');
  const expenses = useCollection('Expense');
  const invoices = useCollection('Invoice');

  const loading = clients.loading || projects.loading || tasks.loading || expenses.loading || invoices.loading;
  const isEmpty = !loading && clients.items.length === 0 && projects.items.length === 0 && invoices.items.length === 0;

  const series = monthSeries(invoices.items, expenses.items, 8);
  const current = series[series.length - 1] || { revenue: 0, expenses: 0 };
  const previous = series[series.length - 2] || { revenue: 0, expenses: 0 };
  const profit = current.revenue - current.expenses;
  const prevProfit = previous.revenue - previous.expenses;
  const outstanding = invoices.items
    .filter((i) => i.status !== 'paid')
    .reduce((s, i) => s + (Number(i.total) || 0), 0);
  const openInvoices = invoices.items.filter((i) => i.status !== 'paid').length;
  const margin = current.revenue ? Math.round((profit / current.revenue) * 100) : 0;

  const cards = [
    {
      label: `Revenue · ${current.month || 'this month'}`,
      value: current.revenue,
      delta: delta(current.revenue, previous.revenue),
      hint: 'vs last month',
      series: series.map((s) => s.revenue || 1),
    },
    {
      label: `Expenses · ${current.month || 'this month'}`,
      value: current.expenses,
      delta: delta(current.expenses, previous.expenses),
      hint: 'vs last month',
      series: series.map((s) => s.expenses || 1),
    },
    {
      label: 'Net profit',
      value: profit,
      delta: delta(profit, prevProfit),
      hint: `margin ${margin}%`,
      series: series.map((s) => s.revenue - s.expenses),
    },
    {
      label: 'Outstanding',
      value: outstanding,
      badge: `${openInvoices} open`,
      hint: 'Awaiting payment',
      series: series.map((s) => s.revenue * 0.4 + 1),
    },
  ];

  const alerts = buildAlerts({
    invoices: invoices.items,
    projects: projects.items,
    tasks: tasks.items,
    expenses: expenses.items,
  });

  const actions = buildActions({
    invoices: invoices.items,
    projects: projects.items,
    tasks: tasks.items,
    expenses: expenses.items,
    clients: clients.items,
  });

  const activeProjects = projects.items
    .filter((p) => p.status === 'active' || p.status === 'planning')
    .slice(0, 4)
    .map((p) => {
      const f = projectFinance(p, expenses.items, invoices.items, tasks.items);
      return { id: p.id, name: p.name, client: p.client_name || 'Internal', budget: p.budget || 0, spent: f.spent, progress: f.progress };
    });

  const recentInvoices = [...invoices.items]
    .sort((a, b) => new Date(b.issue_date || 0) - new Date(a.issue_date || 0))
    .slice(0, 4)
    .map((i) => ({ ...i, client: i.client_name }));

  const hour = new Date().getHours();
  const greeting = hour < 12 ? 'Good morning' : hour < 18 ? 'Good afternoon' : 'Good evening';

  return (
    <div>
      <PageHeader
        eyebrow={`${greeting}, ${userName.split(' ')[0]}`}
        title="Your company, in one place"
        description="Projects, customers, cash and profit — connected and updated in real time."
        actions={
          <>
            <button className="btn-ghost" onClick={() => window.print()}>
              <Download className="h-4 w-4" /> Export
            </button>
            <Link to="/invoices" className="btn-ink">
              <Plus className="h-4 w-4" /> New invoice
            </Link>
          </>
        }
      />

      {loading ? (
        <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 xl:grid-cols-4">
          {[0, 1, 2, 3].map((i) => (
            <div key={i} className="h-[148px] animate-pulse rounded-2xl border border-border bg-card/60" />
          ))}
        </div>
      ) : isEmpty ? (
        <div className="surface p-8 text-center sm:p-12">
          <p className="eyebrow">Empty workspace</p>
          <h2 className="mt-2 text-[22px] tracking-[-0.01em]">No business records yet</h2>
          <p className="mx-auto mt-2 max-w-md text-[13px] leading-relaxed text-muted-foreground">
            Every figure here is calculated from your own customers, projects, invoices and expenses. Add your first
            project, or import the records you already keep in a spreadsheet.
          </p>
          <div className="mt-6 flex flex-wrap items-center justify-center gap-2">
            <Link to="/projects" className="btn-ink">
              <Plus className="h-4 w-4" /> Add first project
            </Link>
            <Link to="/settings" className="btn-ghost">
              Import my data
            </Link>
          </div>
        </div>
      ) : (
        <>
          <KpiRow cards={cards} currency={currency} />

          <div className="mt-6 grid grid-cols-1 gap-6 xl:grid-cols-3">
            <div className="xl:col-span-2">
              <RevenueChart data={series} currency={currency} />
            </div>
            <AttentionPanel alerts={alerts} />
          </div>

          <div className="mt-6 grid grid-cols-1 gap-6 xl:grid-cols-3">
            <div className="xl:col-span-2">
              <ProjectHealth projects={activeProjects} currency={currency} />
            </div>
            <ActionQueue actions={actions} />
          </div>

          <div className="mt-6">
            <RecentInvoices invoices={recentInvoices} currency={currency} />
          </div>

          <div className="mt-6 flex flex-wrap items-center justify-between gap-3 rounded-2xl border border-dashed border-border bg-card/60 px-5 py-4">
            <p className="flex items-center gap-2 text-[12.5px] text-muted-foreground">
              <Sparkles className="h-4 w-4 text-foreground" />
              <span>
                <span className="font-medium text-foreground">Ask the assistant</span> — “which projects are losing
                money?”
              </span>
            </p>
            <Link to="/assistant" className="text-[12.5px] font-medium underline-offset-4 hover:underline">
              Open AI assistant
            </Link>
          </div>
        </>
      )}
    </div>
  );
}
