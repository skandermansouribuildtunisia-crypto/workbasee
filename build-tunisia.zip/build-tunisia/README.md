# build-tunisia.com

React + Vite + Tailwind app (workbase). Backend runs on Base44.

## Run locally
```bash
npm install
npm install -g base44@latest
base44 login    # once per machine
base44 link     # once per clone (writes base44/.app.jsonc)
base44 dev      # starts backend + frontend together
```
Open the URL printed by `base44 dev` (usually http://localhost:5173).

## Build
```bash
npm run build   # output in dist/
```
